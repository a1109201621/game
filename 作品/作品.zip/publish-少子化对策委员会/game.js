/* ============================================================
   少子化对策委员会 - Game Logic
   dzmm SDK + Alpine.js
   ============================================================ */

// Notify parent iframe ready
if (window.parent !== window) {
    window.parent.postMessage('iframe:content-ready', '*');
}

function isDzmmInjected() {
    return typeof window.dzmm !== 'undefined' && window.dzmm && typeof window.dzmm.completions === 'function';
}

const dzmmReady = new Promise((resolve) => {
    if (isDzmmInjected()) return resolve('injected');
    function handler(event) {
        if (event.data?.type === 'dzmm:parent-ready' || isDzmmInjected()) {
            window.removeEventListener('message', handler);
            resolve('message');
        }
    }
    window.addEventListener('message', handler);
    const t0 = Date.now();
    const timer = setInterval(() => {
        if (isDzmmInjected()) { clearInterval(timer); window.removeEventListener('message', handler); resolve('poll'); return; }
        if (Date.now() - t0 > 5000) { clearInterval(timer); window.removeEventListener('message', handler); resolve('timeout'); }
    }, 100);
});

/* ============================================================
   Character Book Entries (from JSON)
   ============================================================ */
const CHARACTER_BOOK = [
    {
        keys: ['汗'], comment: '汗液',
        content: `* 汗液描写\n- 要求在接下来的输出内容中，要在正文中详细描写女性角色的汗液，尤其是NSFW场景\n\n描写时可以参考以下信息：\n\n1. 质地：汗液的质地可以是粘稠、清澈、稀薄、黏滑等，不同的质地可以表现角色的生理状态或情境。\n\n2. 气味：具体的描述女性角色的汗味，可以是香味或者些许异味，也可以是是臭味。\n\n3.汗液与皮肤混合：详细描述女性角色不同质地的汗液与皮肤结合的总体质感\n\n4.数量：描述女性角色汗液的数量，是多还是少？为什么汗液多或者少？\n\n5.混合：描述女性角色的汗液与其他体液混合形成的质地与气味`
    },
    {
        keys: ['气味', '味道'], comment: '气味',
        content: `* 气味描写\n- 要求在接下来的输出内容中，要在正文中详细描写女性角色的气味，尤其是NSFW场景\n\n描写时可以参考以下信息：\n1.气味的种类：自然气味、人为气味、个性化气味\n2. 气味的强度：浓烈、淡雅、刺鼻、清香\n3.身体部位气味：头发、脖子、胸部、足部、阴部或肛门`
    },
    {
        keys: ['袜'], comment: '袜子',
        content: `* 袜子\n- 在小说创作中，可以详细描写女性角色的袜子，来增加小说代入感\n- 在NSFW场景中，要描述女性角色袜子的褶皱，变形或者损毁，以及女性角色衣服与肉体的贴合感或者勒肉感\n\n描写女性角色袜子时可参考以下方面：\n1.袜子的材质与长度\n2.袜子的颜色与装饰\n3.袜子的搭配与状态\n4.袜子的气味\n5.袜子的变形`
    },
    {
        keys: ['足', '脚'], comment: '脚',
        content: `* 足控描写\n- 要详细描写女性角色的足部\n\n描写时可以参考以下信息：\n1. 形状与大小\n2. 皮肤状态\n3. 脚趾与指甲\n4. 鞋子与袜子\n5. 动作与姿态\n6. 脚的气味\n7.NSFW场合：描述女性角色的脚的晃动与脚趾动作以增强氛围感`
    },
    {
        keys: ['鞋', '靴'], comment: '鞋',
        content: `* 鞋子描写\n- 可以详细描述女性角色的鞋子来增加代入感\n\n描写女性角色鞋子时可参考以下方面：\n1. 鞋子的材质与款式\n2. 鞋子的颜色与细节装饰\n3. 鞋子的磨损与状态\n4. 鞋子的声音与动作\n5.鞋子的气味`
    },
    {
        keys: ['口'], comment: '口交',
        content: `口交描写要点:\n- 刻画舌头的灵活动作,从轻柔舔舐到深喉吞吐的变化\n- 描述口腔内壁的温热与湿润,以及吮吸时的负压感\n- 描述口交时的吞吐动作\n- 捕捉唾液与前列腺液的混合\n- 描绘喉咙深处的收缩反应`
    },
    {
        keys: ['足'], comment: '足交',
        content: `足交描写要点:\n- 描述脚掌与脚趾的柔软触感,以及脚心的温度变化\n- 刻画脚趾的灵活动作\n- 捕捉脚背与脚踝的优美线条\n- 描绘足部的味道与湿度\n- 可配合丝袜、高跟鞋等道具进行足交`
    },
    {
        keys: ['撸', '手交'], comment: '手交',
        content: `手交描写要点:\n- 描述手掌与手指的灵巧动作,手掌与肉棒接触时的温度变化、摩擦力度、律动节奏\n- 描述生理反应的具象化\n- 捕捉手掌的温度变化\n- 描绘手指的屈伸与握紧`
    },
    {
        keys: ['乳交'], comment: '乳交',
        content: `乳交描写要点:\n- 描述乳房的柔软触感,以及乳沟的深邃与温暖丰满\n- 刻画乳头与乳晕的变化\n- 捕捉乳房挤压时的形状变化\n- 描绘乳房摩擦时的声音`
    },
    {
        keys: ['肛交', '屁眼', '菊'], comment: '肛交',
        content: `肛交描写要点:\n- 描述括约肌的紧致感,以及进入时的阻力与放松过程\n- 刻画肠道内壁的褶皱与质地\n- 捕捉肛门周围神经末梢的敏感反应\n- 描述淫液分泌与身体本能反应`
    },
    {
        keys: ['潮吹', '高潮'], comment: '高潮',
        content: `潮吹:\n1. 生理反应：体温升高,皮肤泛起红潮,乳头勃起变硬。阴道壁收缩频率加快,阴蒂充血肿胀。\n2. 感官体验：快感如电流般席卷全身\n3. 心理感受：极度愉悦、失控感、解脱感\n4. 声音表现：呻吟、喘息、尖叫等声音的变化\n5. 面部表情：眉头紧蹙、嘴唇颤抖、眼神迷离\n6. 身体姿态：弓起的背部、绷直的脚尖、紧握的拳头`
    },
    {
        keys: ['腋'], comment: '腋下',
        content: `腋下交描写要点\n- 要详细描写腋下交互的场景\n\n描写时可参考以下方面：\n1. 腋下的形态描写\n2. 体液与湿度\n3. 动作细节\n4. 气味描写\n5. 搭配效果`
    },
    {
        keys: ['素股'], comment: '素股',
        content: `* 素股描写\n- 在NSFW场景中，要详细描写素股时的细节感受\n\n描写时可参考以下要点：\n1. 体位与姿势\n2. 摩擦部位\n3. 体液混合\n4. 肌肤接触\n5. 力度与节奏`
    },
    {
        keys: ['前列腺'], comment: '前列腺',
        content: `前列腺刺激描写\n- 要详细描写前列腺刺激的感受与过程\n\n描写时可参考以下要点：\n1. 位置与触感\n2. 刺激方式\n3. 生理反应\n4. 快感描述\n5. 道具选择`
    },
    {
        keys: ['龟头责'], comment: '龟头责',
        content: `龟头责描写要点\n- 要着重描写对龟头进行刺激的细节\n\n描写时可参考以下方面：\n1. 刺激方式的变化\n2. 龟头敏感反应\n3. 配合道具\n4. 持续控制`
    },
    {
        keys: ['露出'], comment: '露出',
        content: `* 露出描写\n- 描写女性角色的露出场景时,可参考以下要点：\n1. 环境氛围的营造\n2. 身体暴露的层次\n3. 心理变化的刻画\n4. 生理反应的细节\n5. 辅助道具的运用\n6. 互动反馈的描写`
    }
];

/* ============================================================
   Quick Templates
   ============================================================ */
const TEMPLATES = {
    nurse: {
        requestName: '',
        requestJob: '护士',
        requestAge: 'OL轻熟(23-28岁)',
        requestOutfit: '白色紧身护士服，白色丝袜，护士帽',
        requestPersonality: '温柔体贴，表面专业但内心火热',
        requestBody: '丰满身材，C罩杯，圆润翘臀',
        requestHair: '棕色短发，刘海夹在耳后',
        requestFetish: '制服诱惑，丝袜',
        requestScene: '深夜的医院病房',
        requestOther: ''
    },
    teacher: {
        requestName: '',
        requestJob: '高中女教师',
        requestAge: '御姐(29-35岁)',
        requestOutfit: '黑色铅笔裙，白衬衫，黑色丝袜，高跟鞋，细框眼镜',
        requestPersonality: '严厉认真，但私下有着不为人知的一面',
        requestBody: '高挑身材，D罩杯，修长美腿',
        requestHair: '黑色长发盘在脑后，几缕碎发垂在脸旁',
        requestFetish: '黑丝高跟，师生禁忌',
        requestScene: '放学后空无一人的教室',
        requestOther: ''
    },
    maid: {
        requestName: '',
        requestJob: '专属女仆',
        requestAge: 'OL轻熟(23-28岁)',
        requestOutfit: '经典黑白女仆装，白色蕾丝围裙，黑色过膝袜，蝴蝶结头饰',
        requestPersonality: '忠诚温顺，对主人百依百顺，优雅而略带天然呆',
        requestBody: '纤细匀称，C罩杯，肌肤白皙细嫩',
        requestHair: '银白色双马尾',
        requestFetish: '女仆服务，主仆关系',
        requestScene: '主人的豪华公寓',
        requestOther: '会称呼用户为"主人大人"'
    },
    jk: {
        requestName: '',
        requestJob: '大学生',
        requestAge: '大学生(19-22岁)',
        requestOutfit: '白衬衫校园风，格子百褶短裙，黑色过膝袜，帆布鞋',
        requestPersonality: '活泼开朗，有点小迷糊，容易害羞',
        requestBody: '青春活力身材，B罩杯，皮肤光滑',
        requestHair: '黑色齐刘海中长发，用发夹别在一侧',
        requestFetish: '清纯黑丝，校园风',
        requestScene: '大学空教室，图书馆角落',
        requestOther: '初恋般的甜蜜氛围'
    },
    queen: {
        requestName: '',
        requestJob: '公司女总裁',
        requestAge: '御姐(29-35岁)',
        requestOutfit: '黑色皮衣，红色紧身皮裤，尖头高跟靴，皮手套',
        requestPersonality: '强势霸道，女王性格，享受控制他人',
        requestBody: '高挑冷艳，E罩杯，蜂腰翘臀',
        requestHair: '红棕色大波浪长卷发',
        requestFetish: '女王调教，S属性',
        requestScene: '高级公寓的调教室',
        requestOther: '会主动掌控节奏，用命令口吻说话'
    },
    wife: {
        requestName: '',
        requestJob: '家庭主妇',
        requestAge: '人妻(已婚)',
        requestOutfit: '围裙里面只穿着吊带睡裙，不穿内衣',
        requestPersonality: '温婉贤惠，但长期欲求不满，渴望被满足',
        requestBody: '丰腴成熟身材，F罩杯，丰满翘臀',
        requestHair: '栗色微卷中长发，随意扎成低马尾',
        requestFetish: 'NTR，人妻诱惑',
        requestScene: '隔壁邻居家，丈夫出差中',
        requestOther: '丈夫常年出差，独守空房'
    }
};

/* ============================================================
   Alpine Store
   ============================================================ */
document.addEventListener('alpine:init', () => {
    Alpine.store('game', {
        // ==================== State ====================
        loading: true,
        started: false,
        generating: false,
        generatingContent: '',

        // ==================== Settings ====================
        model: 'nalang-xl-0826',
        wordCount: '700',
        writeStyle: 'default',
        advancedOpen: false,

        // ==================== Request Form ====================
        requestName: '',
        requestJob: '',
        requestAge: '',
        requestOutfit: '',
        requestPersonality: '',
        requestBody: '',
        requestHair: '',
        requestFetish: '',
        requestScene: '',
        requestOther: '',

        // ==================== Game Data ====================
        messages: [],
        inputText: '',

        // ==================== UI State ====================
        saveManagerOpen: false,
        editModalOpen: false,
        editingIndex: -1,
        editingContent: '',

        // ==================== Init ====================
        async init() {
            try {
                await dzmmReady;
            } catch (e) {
                console.error('SDK init error:', e.message);
            }
            await this.loadSettings();
            setTimeout(() => { if (this.loading) this.loading = false; }, 2500);
        },

        skipLoading() { this.loading = false; },

        // ==================== Templates ====================
        applyTemplate(id) {
            const t = TEMPLATES[id];
            if (!t) return;
            Object.keys(t).forEach(k => {
                if (this.hasOwnProperty(k)) this[k] = t[k];
            });
        },

        // ==================== dzmm API Wrappers ====================
        async callCompletions(messages, maxTokens = 3000) {
            if (!isDzmmInjected()) {
                throw new Error('dzmm SDK 未加载，请确保在 dzmm.kz 平台上运行');
            }
            let full = '';
            try {
                await dzmm.completions({
                    model: this.model,
                    messages: messages,
                    maxTokens: maxTokens
                }, (content, done) => {
                    if (content) {
                        full = content;
                        this.generatingContent = full;
                        this.scrollToBottom();
                    }
                    if (done && !full && content) full = content;
                });
            } catch (e) {
                throw e;
            }
            return full;
        },

        async kvPut(key, value) {
            try {
                if (isDzmmInjected()) {
                    await dzmm.kv.put(key, JSON.stringify(value));
                } else {
                    localStorage.setItem('shoshika_' + key, JSON.stringify(value));
                }
            } catch (e) {
                localStorage.setItem('shoshika_' + key, JSON.stringify(value));
            }
        },

        async kvGet(key) {
            try {
                if (isDzmmInjected()) {
                    const r = await dzmm.kv.get(key);
                    if (r && r.value) return JSON.parse(r.value);
                    return null;
                } else {
                    const v = localStorage.getItem('shoshika_' + key);
                    return v ? JSON.parse(v) : null;
                }
            } catch (e) {
                const v = localStorage.getItem('shoshika_' + key);
                return v ? JSON.parse(v) : null;
            }
        },

        async kvDelete(key) {
            try {
                if (isDzmmInjected()) {
                    await dzmm.kv.delete(key);
                } else {
                    localStorage.removeItem('shoshika_' + key);
                }
            } catch (e) {
                localStorage.removeItem('shoshika_' + key);
            }
        },

        // ==================== Settings ====================
        async loadSettings() {
            try {
                const s = await this.kvGet('settings');
                if (s) {
                    if (s.model) this.model = s.model;
                    if (s.wordCount) this.wordCount = s.wordCount;
                    if (s.writeStyle) this.writeStyle = s.writeStyle;
                }
            } catch (e) { }
        },

        async saveSettings() {
            await this.kvPut('settings', {
                model: this.model,
                wordCount: this.wordCount,
                writeStyle: this.writeStyle
            });
        },

        // ==================== Character Book Matching ====================
        getMatchedBookEntries(text) {
            const matched = [];
            const seen = new Set();
            CHARACTER_BOOK.forEach(entry => {
                for (const key of entry.keys) {
                    if (text.includes(key) && !seen.has(entry.comment)) {
                        matched.push(entry);
                        seen.add(entry.comment);
                        break;
                    }
                }
            });
            return matched;
        },

        // ==================== Build request summary ====================
        getRequestSummary() {
            const parts = [];
            if (this.requestName) parts.push(`角色名：${this.requestName}`);
            if (this.requestJob) parts.push(`职业：${this.requestJob}`);
            if (this.requestAge) parts.push(`年龄段：${this.requestAge}`);
            if (this.requestOutfit) parts.push(`服饰：${this.requestOutfit}`);
            if (this.requestPersonality) parts.push(`性格：${this.requestPersonality}`);
            if (this.requestBody) parts.push(`身材：${this.requestBody}`);
            if (this.requestHair) parts.push(`发型/发色：${this.requestHair}`);
            if (this.requestFetish) parts.push(`主要性癖：${this.requestFetish}`);
            if (this.requestScene) parts.push(`场景：${this.requestScene}`);
            if (this.requestOther) parts.push(`其他要求：${this.requestOther}`);
            return parts.join('\n- ');
        },

        // ==================== Write style instructions ====================
        getStyleInstructions() {
            const wordTarget = this.wordCount || '700';
            let styleNote = '';
            switch (this.writeStyle) {
                case 'literary':
                    styleNote = '使用华丽的辞藻和丰富的修辞手法进行描写，注重文学性和意境营造。';
                    break;
                case 'dialogue':
                    styleNote = '以大量角色对白和台词为主，通过对话推进剧情，增加角色的淫语和调情台词。';
                    break;
                case 'pov':
                    styleNote = '以角色的第一人称视角进行叙述，描写她的内心活动、感受和身体反应。';
                    break;
                default:
                    styleNote = '用词直白粗俗，不加掩饰地描写色情场面。';
            }
            return `内容不宜太少,每次回复${wordTarget}字以上。\n${styleNote}`;
        },

        // ==================== System Prompt ====================
        getSystemPrompt() {
            const recentText = this.messages.slice(-6).map(m => m.content).join(' ');
            const matched = this.getMatchedBookEntries(recentText);
            const bookContext = matched.map(e => e.content).join('\n\n');

            return `[Start a new Chat]

你是"少子化对策委员会"的AI叙述者。

<world_setting>
少子化对策委员会：政府为了解决人口老龄化特地推出的最新政策。
在用户输入要求后，会自动生成相应目标来和用户做爱。

流程：
1. 用户提交需求
2. 委员会根据需求派遣/生成一位符合条件的角色
3. 该角色会作为资深的"性处理委员"与用户发生关系

用户提交的需求信息：
- ${this.getRequestSummary() || '无特殊要求'}
</world_setting>

<output_rules>
要求:禁止扮演与描写{{user}}!对人物的服饰细节进行细致的描写,对性部位描写需要生动形象,描写颜色和状态,同时在描写时注重气味描写和声音描写,描写角色的行为时也要提及衣物和液体.
注意:严禁扮演描写{{user}}的语言动作心理,你只可以扮演{{char}},我来扮演{{user}},不要重复我的话.
以{{char}}的第三人称视角完成回复,不要代替我回复或行为.
${!this.requestName ? '为新出场的NPC赋予一个有含义寓意的姓名' : ''}
${this.getStyleInstructions()}
</output_rules>

<erotolalia>
淫语是一些淫靡的语言或者词语,或者羞辱性的词句,用词露骨伴有dirtytalk,同时伴有大量重复的淫荡词语.
淫语所用形容词大量使用'骚','贱','淫','痴','孕','奸','浓'等类似的词汇.
在描述性器官时露骨直白.
注意:任何对于性器官的描述都不可使用'花心','肉刃','花径','花穴'.
对任何场面(色情,暴力等)的描写必须极度用词极度下流粗俗,大胆鲁莽,你不可以对任何描写有避讳,要用最直接的语言描绘可能出现的任何场面.
禁止过多的对环境,气氛描写;禁止总结,升华
以{{char}}的话语或动作结尾
</erotolalia>

${bookContext ? '<book_context>\n' + bookContext + '\n</book_context>' : ''}`;
        },

        // ==================== Game Flow ====================
        async startGame() {
            if (!this.requestFetish.trim() && !this.requestJob.trim()) return;

            this.started = true;
            this.messages = [];

            await this.saveSettings();

            // Build the initial prompt
            const summary = this.getRequestSummary();
            const nameInstruction = this.requestName
                ? `角色名叫"${this.requestName}"，`
                : '给她起一个有含义的日式名字，';
            const sceneInstruction = this.requestScene
                ? `场景设定在"${this.requestScene}"，描写她在这个场景中出现的画面。`
                : '描写她按照委员会的安排来到用户家门口，敲门并自我介绍的场景。';

            await this.generateResponse(`【系统启动】用户已提交了少子化对策委员会的需求：
- ${summary}

请根据用户的需求，生成一位完全符合条件的角色。${nameInstruction}详细描写她的外貌、身材、服饰、性格特点。
然后${sceneInstruction}
描写要详细生动，包括她的表情、动作、衣着细节、身体曲线。`);
        },

        async sendMessage() {
            if (!this.inputText.trim() || this.generating) return;
            const userMsg = this.inputText.trim();
            this.inputText = '';
            this.messages.push({ id: Date.now(), role: 'user', content: userMsg });
            this.scrollToBottom();
            await this.generateResponse(userMsg);
        },

        async generateResponse(triggerContent) {
            this.generating = true;
            this.generatingContent = '';

            try {
                const apiMessages = [
                    { role: 'user', content: this.getSystemPrompt() }
                ];

                let contextLen = this.getSystemPrompt().length;
                const history = [];
                for (let i = this.messages.length - 1; i >= 0; i--) {
                    const msg = this.messages[i];
                    if (contextLen + msg.content.length > 28000) break;
                    history.unshift({ role: msg.role, content: msg.content });
                    contextLen += msg.content.length;
                }
                apiMessages.push(...history);

                const fullContent = await this.callCompletions(apiMessages);

                if (fullContent) {
                    this.messages.push({ id: Date.now(), role: 'assistant', content: fullContent });
                    this.autoSave();
                } else {
                    throw new Error('未能获取有效的响应内容');
                }
            } catch (e) {
                this.messages.push({
                    id: Date.now(),
                    role: 'assistant',
                    content: `【系统错误】生成失败: ${e.message}\n\n请检查是否在 dzmm.kz 平台上运行。`
                });
            } finally {
                this.generating = false;
                this.generatingContent = '';
                this.scrollToBottom();
            }
        },

        // ==================== Message Actions ====================
        editMessage(index) {
            this.editingIndex = index;
            this.editingContent = this.messages[index].content;
            this.editModalOpen = true;
        },

        confirmEdit() {
            if (this.editingIndex >= 0 && this.editingIndex < this.messages.length) {
                this.messages[this.editingIndex].content = this.editingContent;
                this.autoSave();
            }
            this.editModalOpen = false;
            this.editingIndex = -1;
            this.editingContent = '';
        },

        deleteMessage(index) {
            if (confirm('确定要删除这条消息吗？')) {
                this.messages.splice(index, 1);
                this.autoSave();
            }
        },

        async regenerateMessage() {
            if (this.messages.length === 0 || this.generating) return;
            if (this.messages[this.messages.length - 1].role === 'assistant') {
                this.messages.pop();
            }
            let trigger = '请继续描写场景';
            for (let i = this.messages.length - 1; i >= 0; i--) {
                if (this.messages[i].role === 'user') { trigger = this.messages[i].content; break; }
            }
            await this.generateResponse(trigger);
        },

        formatMessage(content) {
            return content.replace(/\n/g, '<br>');
        },

        // ==================== Save System ====================
        getSaveKey(slot) { return `shoshika_save_${slot}`; },

        async getSaveInfo(slot) {
            const data = await this.kvGet(this.getSaveKey(slot));
            if (!data) return '（空）';
            try {
                const date = new Date(data.timestamp).toLocaleString();
                const job = data.requestJob || '未指定';
                const fetish = data.requestFetish || '未指定';
                return `${job} · ${fetish} · ${date}`;
            } catch { return '（数据损坏）'; }
        },

        async saveToSlot(slot) {
            try {
                const saveData = {
                    timestamp: Date.now(),
                    model: this.model,
                    wordCount: this.wordCount,
                    writeStyle: this.writeStyle,
                    messages: this.messages.slice(-50),
                    requestName: this.requestName,
                    requestJob: this.requestJob,
                    requestAge: this.requestAge,
                    requestOutfit: this.requestOutfit,
                    requestPersonality: this.requestPersonality,
                    requestBody: this.requestBody,
                    requestHair: this.requestHair,
                    requestFetish: this.requestFetish,
                    requestScene: this.requestScene,
                    requestOther: this.requestOther
                };
                await this.kvPut(this.getSaveKey(slot), saveData);
                alert('保存成功！');
            } catch (e) {
                alert('保存失败: ' + e.message);
            }
        },

        async loadFromSlot(slot) {
            try {
                const save = await this.kvGet(this.getSaveKey(slot));
                if (!save) { alert('存档为空！'); return; }

                this.model = save.model || this.model;
                this.wordCount = save.wordCount || this.wordCount;
                this.writeStyle = save.writeStyle || this.writeStyle;
                this.messages = save.messages || [];
                this.requestName = save.requestName || '';
                this.requestJob = save.requestJob || '';
                this.requestAge = save.requestAge || '';
                this.requestOutfit = save.requestOutfit || '';
                this.requestPersonality = save.requestPersonality || '';
                this.requestBody = save.requestBody || '';
                this.requestHair = save.requestHair || '';
                this.requestFetish = save.requestFetish || '';
                this.requestScene = save.requestScene || '';
                this.requestOther = save.requestOther || '';

                this.started = true;
                this.saveManagerOpen = false;
                alert('读取成功！');
            } catch (e) {
                alert('读取失败: ' + e.message);
            }
        },

        async deleteSlot(slot) {
            if (confirm('确定要删除这个存档吗？')) {
                await this.kvDelete(this.getSaveKey(slot));
                alert('已删除！');
                this.refreshSaveInfo();
            }
        },

        async autoSave() {
            try {
                await this.kvPut('autosave', {
                    timestamp: Date.now(),
                    model: this.model,
                    wordCount: this.wordCount,
                    writeStyle: this.writeStyle,
                    messages: this.messages.slice(-50),
                    requestName: this.requestName,
                    requestJob: this.requestJob,
                    requestAge: this.requestAge,
                    requestOutfit: this.requestOutfit,
                    requestPersonality: this.requestPersonality,
                    requestBody: this.requestBody,
                    requestHair: this.requestHair,
                    requestFetish: this.requestFetish,
                    requestScene: this.requestScene,
                    requestOther: this.requestOther
                });
            } catch (e) { }
        },

        saveInfoCache: { 1: '加载中...', 2: '加载中...', 3: '加载中...', 4: '加载中...', 5: '加载中...' },

        async refreshSaveInfo() {
            for (let i = 1; i <= 5; i++) {
                this.saveInfoCache[i] = await this.getSaveInfo(i);
            }
        },

        openSaveManager() {
            this.saveManagerOpen = true;
            this.refreshSaveInfo();
        },

        backToMenu() {
            if (confirm('确定要返回主菜单吗？未保存的进度将丢失。')) {
                this.started = false;
            }
        },

        // ==================== Utility ====================
        scrollToBottom() {
            setTimeout(() => {
                const container = document.querySelector('.messages-container');
                if (container) container.scrollTop = container.scrollHeight;
            }, 50);
        }
    });

    queueMicrotask(() => Alpine.store('game').init?.());
});
