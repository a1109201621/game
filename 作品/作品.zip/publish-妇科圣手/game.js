// 通知父窗口 iframe 已准备好
if (window.parent !== window) {
    window.parent.postMessage('iframe:content-ready', '*');
}

// 等待 DZMM API 就绪
const dzmmReady = new Promise((resolve) => {
    window.addEventListener('message', function handler(event) {
        if (event.data?.type === 'dzmm:ready') {
            window.removeEventListener('message', handler);
            resolve();
        }
    });
    setTimeout(resolve, 5000);
});

// ==================== 系统提示词模板（从妇科圣手.json世界书提取） ====================

const LORE_MODULES = {
    '医院设定': { keys: ['医院','诊室','诊疗室','VIP','挂号','病房','护士站','仁和','检查室'], content: `<hospital name="仁和私立妇产医院">
  概述: 市内高端私立妇产医院。{{user}}拥有专属VIP诊疗套间，配有可调式诊疗椅、隐私帘、内窥设备、超声波仪等全套妇科器械。
  诊疗流程: 挂号 → 候诊 → 问询 → 要求脱衣换检查服 → 上诊疗椅 → 体格检查 → 器械检查(窥阴器/B超) → 处方。每个环节都是{{user}}的操作窗口。
  声望: {{user}}被称为"妇科圣手"，患者极度信任，这份信任是最好的掩护。
</hospital>` },

    '海城设定': { keys: ['海城','CBD','高校','大学','碧湾','住宅','人妻','网红','商场'], content: `<city name="海城">
  重要地点:
    - CBD商业区: 职业OL出没，常穿套装丝袜。
    - 城东高校区: 年轻女大学生聚集，校医院会向仁和转介患者。
    - 碧湾住宅区: 居住大量年轻人妻、单母。
    - 网红街: 网红模特聚集地。
</city>` },

    '主角设定': { keys: ['能力','医术','话术','体力','道具','药物','麻醉','心理','原则','权威','节奏'], content: `<player_character name="{{user}}">
  特殊能力:
    专业权威: 可合理要求患者脱衣、张开双腿接受私密检查。
    药物知识: 精通镇静剂、催情剂，可借"治疗"之名使用。
    心理操控: 善用医学术语制造无名焦虑，再温柔安抚建立依赖。
  行为准则:
    节奏控制: 过于激烈会导致NPC大叫报警。必须结合目标顺从度循序渐进。
</player_character>` },

    '系统机制': { keys: ['机制','遭遇','偶遇','复诊','反应','顺从','反抗','成就','进度'], content: `<game_mechanics>
  遭遇系统:
    方式: 1.主动就诊(最安全) 2.院外偶遇(需找理由引诱就诊) 3.复诊回访
  NPC反应判定:
    顺从度高(配合) -> 顺从度中(表达不适但不反抗) -> 顺从度低(感觉异常即刻反抗质疑)
  进度与成就系统:
    侵犯不同目标（OL、学生、人妻等）可解锁记录；连续作案极易引起注意。
</game_mechanics>` },

    '风险机制': { keys: ['风险','警戒','调查','报警','被抓','识破','警察','女警'], content: `<risk_system name="风险机制">
  警戒度(0-100隐性值):
    温和擦边+5~10，趁机猥亵/下药+15~25，强制激烈+30~50。被识破大喊额外+20。安抚成功-5~10。
  阈值与女警:
    警戒度50/侵犯3次(女警开始暗查) -> 70/5次(女警患者身份潜入) -> 90/7次(上门对峙) -> 100(Game Over)。
    成功攻略女警后，警戒度上限提升至150，获得查案掩护。
</risk_system>` }
};

const SU_WANQING = `<character_information character="苏晚晴">
核心身份: 女, 28岁, 海城市公安局刑侦支队探员
背景: 警察世家出身，从小在严格家教下长大。曾独自破获连环性骚扰案件，获"铁娘子"称号。

外貌: 高挑匀称172cm，瓜子脸五官精致锐利，黑色长发高马尾，深棕色丹凤眼目光锐利。C罩杯制服下不明显，腰臀比极佳。穿制服时干练利落，换上便装后曲线毕露。

性格: ISTJ，刚正不阿、冷峻、执着、外冷内热。对"那方面"毫无经验，是隐藏的处女。面对妇科检查会产生强烈羞耻感和紧张感——这是她最大的破绽。

攻略关键:
  弱点利用: 她对妇科检查的恐惧和羞耻感是突破口。如果{{user}}能在"正常诊疗"中让她产生身体反应，心理防线会出现严重动摇。
  攻略成功: 让苏晚晴从调查者变为共犯，利用职权帮助{{user}}掩护。
  攻略失败: 苏晚晴直接逮捕{{user}}——Game Over。
</character_information>`;

// 特化描写模板（按关键词触发）
const SPECIALIZATIONS = {
    '丝袜': { keys: ['丝袜','连裤袜','吊带袜','黑丝','肉丝','白丝','pantyhose','stockings'], content: `<STOCKINGS_SPECIALIZATION>
名称: 丝袜特化
感官约束：区分不同丝袜类型的视觉与触觉差异；隔着丝袜的暧昧摩擦感；撕裂丝袜的破坏感；穿丝袜在诊疗椅上的独特场景。
</STOCKINGS_SPECIALIZATION>` },
    '足交': { keys: ['足交','脚','足','脚趾','脚心','脚掌','footjob','踩'], content: `<FOOTJOB_SPECIALIZATION>
名称: 足交特化
感官约束：根据NPC职业描写不同质感足部；以"检查下肢血液循环"为切入点；心理崩塌与高潮反馈的肉体描写。
</FOOTJOB_SPECIALIZATION>` },
    '口交': { keys: ['口交','深喉','含住','舔','吸','blowjob','oral'], content: `<BLOWJOB_SPECIALIZATION>
名称: 口交特化
感官约束：口腔温热包裹感；面部屈辱与崩坏描写；唾液污染的视觉冲击；以"口腔黏膜检查"为切入点。
</BLOWJOB_SPECIALIZATION>` },
    '性交': { keys: ['插入','性交','做爱','进入','抽插','射','内射','sex'], content: `<SEX_SPECIALIZATION>
名称: 性交特化
感官约束：插入瞬间的极限描写；诊疗椅的独特体位利用；身体背叛与心理撕裂；高潮与内射的终极背德感。
</SEX_SPECIALIZATION>` },
    '诊疗': { keys: ['检查','诊疗','窥阴器','触诊','诊疗椅','内检','B超','探头','宫颈'], content: `<GYNECOLOGICAL_EXAM_SPECIALIZATION>
名称: 妇科诊疗特化
感官约束：合法外衣下的越界触碰；器械侵入的双重体验；赤裸暴露的绝对羞耻；信任崩塌的致命一击。
</GYNECOLOGICAL_EXAM_SPECIALIZATION>` },
    '药物': { keys: ['药物','下药','催眠','镇静','麻醉','迷药','注射','催情'], content: `<DRUG_HYPNOSIS_SPECIALIZATION>
名称: 药物催眠特化
感官约束：意识模糊的朦胧美学；药物介质的场景合理性；半梦半醒的身体反应；苏醒后的认知断层。
</DRUG_HYPNOSIS_SPECIALIZATION>` },
    '偷拍': { keys: ['偷拍','拍摄','录像','摄像头','要挟','威胁','把柄','照片'], content: `<BLACKMAIL_SPECIALIZATION>
名称: 偷拍要挟特化
感官约束：隐蔽拍摄的紧张感；要挟揭示的权力碾压；屈从后的堕落螺旋；秘密共犯的扭曲关系。
</BLACKMAIL_SPECIALIZATION>` }
};

// NPC随机属性池（从regex_scripts提取）
const NPC_POOLS = {
    身份: ['CBD白领OL','大学本科生','大学研究生','年轻人妻','单亲妈妈','美妆网红','健身教练','瑜伽教练','公司女高管','幼儿园老师','护士同事','银行柜员','空姐','模特','女大学生(校医院转介)','咖啡店店员'],
    性格: ['傲娇高冷','内向害羞','放荡大胆','温柔顺从','泼辣直爽','天然呆','知性优雅','叛逆不羁','楚楚可怜','妩媚勾人','一本正经','单纯无知','多疑敏感','欲求不满'],
    胸围: ['贫乳A罩杯','娇小B罩杯','标准C罩杯','丰满D罩杯','巨乳E罩杯','爆乳F罩杯'],
    腰臀比: ['纤细蜂腰/浑圆翘臀','匀称腰身/标准臀型','略有赘肉/饱满圆臀','水蛇腰/蜜桃臀','盈盈一握/宽胯大臀'],
    服装: ['职业套装+肉色丝袜+高跟鞋','校服短裙+白色过膝袜','居家连衣裙+蕾丝内衣','运动背心+紧身瑜伽裤','名牌时装+黑色丝袜+尖头高跟','T恤牛仔裤+可爱内衣','低胸吊带裙+不穿内衣','护士制服+白色丝袜','OL衬衫+包臀裙+吊带袜'],
    当前状态: ['独自一人前来就诊','有闺蜜陪同(闺蜜在候诊区)','有男友/丈夫陪同(在楼下等待)','独自一人在院外偶遇','与朋友在一起(需制造独处机会)']
};

function randomPick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

function generateRandomNPC() {
    return {
        身份: randomPick(NPC_POOLS.身份),
        性格: randomPick(NPC_POOLS.性格),
        胸围: randomPick(NPC_POOLS.胸围),
        腰臀比: randomPick(NPC_POOLS.腰臀比),
        服装: randomPick(NPC_POOLS.服装),
        当前状态: randomPick(NPC_POOLS.当前状态)
    };
}

// ==================== 主游戏逻辑 ====================

document.addEventListener('alpine:init', () => {
    Alpine.store('game', {
        // ===== 基础状态 =====
        loading: true,
        started: false,
        inGame: false,
        generating: false,
        generatingContent: '',

        // ===== 玩家设置 =====
        playerName: '',
        selectedModel: 'nalang-xl-0826',
        replyMinChars: 400,
        replyMaxChars: 1200,

        // ===== 游戏状态（对应原MVU Schema） =====
        gameState: {
            行动选项: [],
            世界: { 当前位置: '仁和医院 - VIP诊疗室', 当前时间: '第1天 08:00', 场景氛围: '宁静的清晨' },
            主角: {
                声望: '妇科圣手 - 德高望重', 金钱: 50000, 状态: '精神饱满', 今日患者数: 0,
                道具: '镇静剂x3, 催情凝胶x2, 隐藏摄像头x1',
                能力: { 医术: 90, 话术: 70, 体力: 60 }
            },
            风险面板: { 警戒度: 0, 警戒上限: 100, 侵犯计数: 0, 女警状态: '未介入', 女警好感度: 0, 女警已攻略: false },
            当前目标: { 姓名: '无', 身份: '无', 外貌: '无', 服装: '无', 性格: '无', 当前状态: '无', 顺从度: 30, 警觉度: 50 },
            攻略记录: {},
            成就: {}
        },

        // ===== UI状态 =====
        activePanel: '',
        messages: [],
        inputText: '',

        // ===== 弹窗 =====
        saveManagerOpen: false,
        editModalOpen: false,
        editingIndex: -1,
        editingContent: '',

        // ===== 存档缓存 =====
        _saveCache: {},

        // ===== Debug =====
        debugOpen: false,
        debugTab: 'logs',
        debugLogs: [],
        debugPrompts: [],
        debugPos: { x: 50, y: 50 },
        _dragging: false,
        _dragOffset: { x: 0, y: 0 },

        // ===== 初始化 =====
        async init() {
            try {
                await dzmmReady;
                await this.tryRestoreFromKV();
            } catch (e) {
                this.logDebug('error', '初始化错误: ' + e.message);
            }
            setTimeout(() => { if (this.loading) this.loading = false; }, 2500);
        },

        skipLoading() { this.loading = false; },

        // ===== 开始新游戏 =====
        startNewGame() {
            if (!this.playerName) return;
            this.started = true;
            this.inGame = true;
            this.messages = [];
            this.resetGameState();
            this.generateOpening();
        },

        resetGameState() {
            this.gameState = {
                行动选项: [],
                世界: { 当前位置: '仁和医院2F - VIP诊疗室', 当前时间: '第1天 08:30', 场景氛围: '宁静的清晨 ☀️' },
                主角: {
                    声望: '妇科圣手 - 德高望重', 金钱: 50000, 状态: '精神饱满', 今日患者数: 0,
                    道具: '镇静剂x3, 催情凝胶x2, 隐藏摄像头x1',
                    能力: { 医术: 90, 话术: 70, 体力: 60 }
                },
                风险面板: { 警戒度: 0, 警戒上限: 100, 侵犯计数: 0, 女警状态: '未介入', 女警好感度: 0, 女警已攻略: false },
                当前目标: { 姓名: '无', 身份: '无', 外貌: '无', 服装: '无', 性格: '无', 当前状态: '无', 顺从度: 30, 警觉度: 50 },
                攻略记录: {},
                成就: {}
            };
        },

        generateOpening() {
            const name = this.playerName;
            const opening = `清晨七点半，你的手机闹钟准时响起，播放着某个古典钢琴曲。

你伸手关掉闹钟，从宽敞的公寓卧室中坐起身。落地窗外，海城CBD的天际线在晨曦中闪着金光，远处海面上漂浮着几片薄云。这是你来到这座城市的第八年——从一个外地来的住院医师，到如今全市闻名的"妇科圣手"。

洗漱、穿上量身定做的白大褂，对着镜子整理领口。镜中的你，相貌端正、气质沉稳，任谁看到都会觉得这是一位值得信赖的好医生。

你微微一笑。

八点整，你驱车抵达仁和私立妇产医院。豪华大厅里已经有几名女性在候诊区等待——有穿着职业套装的白领，有背着书包的学生模样的女孩，还有推着婴儿车的年轻妈妈。前台护士小李看到你，立刻站起身迎接：

"主任早！今天预约了6位患者，第一位是9点的，VIP诊室已经准备好了。"

你点点头，乘坐专用电梯来到二楼的VIP诊疗套间。推开门——宽敞的诊室里，可调式妇科诊疗椅在无影灯下泛着冷光，各种精密器械整齐排列在不锈钢推车上，窗帘被拉上营造出私密的氛围。你还有半个小时的准备时间。

你的手指划过那张诊疗椅的角度调节按钮，嘴角勾起一个只有自己才懂的弧度。

新的一天，新的"诊疗"，即将开始。`;

            this.messages.push({
                id: Date.now(),
                role: 'assistant',
                content: opening
            });

            this.gameState.行动选项 = [
                "<font color='#60a5fa'>😏 迎接下一位患者</font>",
                "<font color='#a78bfa'>📋 查看今日预约名单</font>",
                "<font color='#34d399'>🏥 在诊室里检查器械准备</font>"
            ];

            this.scrollToBottom();
            this.autoSave();
        },

        // ===== 构建系统提示词 =====
        buildSystemPrompt(userMessage) {
            const name = this.playerName;
            let prompt = `【系统指令枢纽】
您扮演《妇科圣手》独立互动游戏的Game Master。

${name}是海城仁和私立医院的王牌妇科主任。表面是受人尊敬的医学权威，暗地里却利用妇科检查的绝对权力（要求脱衣、触诊、各种器械检查）满足私欲，调教患者。

核心规则：
1. 细腻描绘：每次生成新NPC或角色更衣时，极度细腻地描写面容、身材(胸腰臀)、大腿线条及内衣质感细节。
2. 还原流程：严格执行 问诊→要求脱衣更衣→上可调式诊疗椅张开双腿→触诊→器械检查 的医疗壳子，在此过程中逐步升级越界行为。
3. 风险反馈：目标性格决定其对越界行为的顺从度。过于粗暴会导致大叫挣扎、引来护士或加剧报警风险(提升警戒度)。
4. 感官体验：围绕视觉(肉体/表情扭曲)、触觉(隔着丝袜/粘膜温度)、听觉(娇喘/冰冷器械声)和嗅觉(消毒水/体液)展开描写。极致渲染权力碾压下的背德刺激。`;

            // 动态注入基础设定库
            for (const [modName, mod] of Object.entries(LORE_MODULES)) {
                if (mod.keys.some(k => userMessage.includes(k))) {
                    prompt += '\n\n' + mod.content.replace(/\{\{user\}\}/g, name);
                }
            }

            // 动态注入苏晚晴（警戒度>=50 或 用户提及相关关键词）
            const policeKeywords = ['苏晚晴','女警','警察','刑警','警官','调查','公安'];
            const shouldInjectPolice = this.gameState.风险面板.警戒度 >= 50 ||
                policeKeywords.some(k => userMessage.includes(k));
            if (shouldInjectPolice) {
                prompt += '\n\n' + SU_WANQING.replace(/\{\{user\}\}/g, name);
            }

            // 动态注入特化描写
            for (const [specName, spec] of Object.entries(SPECIALIZATIONS)) {
                if (spec.keys.some(k => userMessage.includes(k))) {
                    prompt += '\n\n' + spec.content.replace(/\{\{user\}\}/g, name);
                }
            }

            // 当前状态
            prompt += `\n\n<current_state>
${JSON.stringify(this.gameState, null, 2)}
</current_state>`;

            // 变量更新输出格式
            prompt += `\n\n<output_rules>
在你的回复正文之后，必须输出状态更新块。格式如下：

###STATE
{
  "行动选项": ["<font color='#a78bfa'>😏选项1</font>", "<font color='#60a5fa'>🥺选项2</font>", "<font color='#ef4444'>😈选项3</font>"],
  "世界": { "当前位置": "位置", "当前时间": "第N天 HH:MM", "场景氛围": "氛围" },
  "主角": { "声望": "...", "金钱": 数字, "状态": "...", "今日患者数": 数字, "道具": "...", "能力": { "医术": 数字, "话术": 数字, "体力": 数字 } },
  "风险面板": { "警戒度": 数字, "警戒上限": 数字, "侵犯计数": 数字, "女警状态": "...", "女警好感度": 数字, "女警已攻略": bool },
  "当前目标": { "姓名": "...", "身份": "...", "外貌": "...", "服装": "...", "性格": "...", "当前状态": "...", "顺从度": 数字, "警觉度": 数字 },
  "攻略记录": { "NPC名": { "身份": "...", "状态": "...", "顺从度": 数字, "备注": "..." } },
  "成就": { "成就名": { "已达成": bool, "描述": "..." } }
}
###END

重要规则：
- 行动选项：给出3个紧密衔接剧情的选项，选项前加 emoji，用 <font color="颜色"> 包裹
- 所有数值字段必须是数字而非字符串
- 攻略记录和成就是增量更新，保留之前的记录
- 当前目标在NPC离开后清空为"无"
- 警戒度变化要根据行为激烈程度合理增减
- 本次回复正文${this.replyMinChars}-${this.replyMaxChars}字
</output_rules>`;

            return prompt;
        },

        // ===== 处理NPC生成 =====
        buildNPCGenerationPrompt(userMessage) {
            // 检测是否需要生成新NPC
            const newPatientKeywords = ['迎接下一位患者','迎接下一个客人','下一位患者','下一个患者','新患者'];
            if (newPatientKeywords.some(k => userMessage.includes(k) || this.stripHtml(userMessage).includes(k))) {
                const npc = generateRandomNPC();
                return `请根据以下随机属性生成一名细节极度丰富的女性NPC角色并引入剧情：
身份: ${npc.身份}
性格: ${npc.性格}
胸围: ${npc.胸围}
腰臀比: ${npc.腰臀比}
服装: ${npc.服装}
当前状态: ${npc.当前状态}

必须在NPC出场时用极细腻的笔触描绘其完整外貌——面容、发型、身材曲线、腿部线条、当前服装和内衣细节。`;
            }
            return null;
        },

        stripHtml(html) {
            const tmp = document.createElement('div');
            tmp.innerHTML = html;
            return tmp.textContent || tmp.innerText || '';
        },

        // ===== 发送消息 =====
        async sendMessage() {
            if (!this.inputText.trim() || this.generating) return;
            const userMessage = this.inputText.trim();
            this.inputText = '';
            this.messages.push({ id: Date.now(), role: 'user', content: userMessage });
            this.scrollToBottom();
            await this.generateResponse(userMessage);
        },

        // ===== 选择行动选项 =====
        async selectAction(opt) {
            if (this.generating) return;
            const cleanText = this.stripHtml(opt).trim();
            this.messages.push({ id: Date.now(), role: 'user', content: cleanText });
            this.scrollToBottom();
            await this.generateResponse(cleanText);
        },

        // ===== 生成AI回复 =====
        async generateResponse(userMessage) {
            this.generating = true;
            this.generatingContent = '';

            try {
                const systemPrompt = this.buildSystemPrompt(userMessage);
                const npcPrompt = this.buildNPCGenerationPrompt(userMessage);

                // 构建消息列表
                const storyContext = this.getStoryContext(12);
                const msgs = [
                    { role: 'user', content: systemPrompt },
                    ...storyContext,
                    { role: 'user', content: npcPrompt ? npcPrompt + '\n\n玩家行动：' + userMessage : userMessage }
                ];

                this.logDebug('info', '发送AI请求, 模型:' + this.selectedModel);
                this.logPrompt('发送', systemPrompt.substring(0, 500) + '...');

                let content = '';
                await window.dzmm.completions(
                    { model: this.selectedModel, messages: msgs, maxTokens: 3000 },
                    async (newContent, done) => {
                        content = newContent;
                        this.generatingContent = content;
                        this.scrollToBottom();

                        if (done && content) {
                            this.logPrompt('收到', content.substring(0, 300) + '...');

                            // 解析状态更新
                            this.parseStateUpdate(content);

                            // 清理状态标记
                            const cleanContent = content
                                .replace(/###\s*STATE[\s\S]*?###\s*END/g, '')
                                .trim();

                            this.messages.push({
                                id: Date.now(),
                                role: 'assistant',
                                content: cleanContent
                            });

                            // 保存到 chat API
                            try {
                                await window.dzmm.chat.insert(null, [
                                    { role: 'user', content: userMessage },
                                    { role: 'assistant', content: content }
                                ]);
                            } catch (e) {
                                this.logDebug('warn', '保存聊天记录失败: ' + e.message);
                            }

                            this.autoSave();
                        }
                    }
                );
            } catch (e) {
                this.logDebug('error', '生成回复失败: ' + e.message);
                this.messages.push({
                    id: Date.now(),
                    role: 'system',
                    content: `【系统】生成回复失败: ${e.message}\n请检查网络连接后重试。`
                });
            } finally {
                this.generating = false;
                this.generatingContent = '';
                this.scrollToBottom();
            }
        },

        // ===== 解析状态更新 =====
        parseStateUpdate(content) {
            const match = content.match(/###\s*STATE\s*([\s\S]*?)\s*###\s*END/);
            if (!match) {
                this.logDebug('warn', '未找到STATE块');
                return;
            }

            try {
                let jsonStr = match[1].trim();
                // 修复常见JSON问题
                jsonStr = jsonStr.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
                const update = JSON.parse(jsonStr);

                // 合并更新
                if (update.行动选项) this.gameState.行动选项 = update.行动选项;
                if (update.世界) Object.assign(this.gameState.世界, update.世界);
                if (update.主角) {
                    if (update.主角.能力) Object.assign(this.gameState.主角.能力, update.主角.能力);
                    const { 能力, ...rest } = update.主角;
                    Object.assign(this.gameState.主角, rest);
                    // 钳制数值
                    this.gameState.主角.金钱 = Math.max(0, this.gameState.主角.金钱);
                    for (const k of ['医术','话术','体力']) {
                        this.gameState.主角.能力[k] = Math.max(0, Math.min(100, this.gameState.主角.能力[k]));
                    }
                }
                if (update.风险面板) {
                    Object.assign(this.gameState.风险面板, update.风险面板);
                    this.gameState.风险面板.警戒度 = Math.max(0, Math.min(this.gameState.风险面板.警戒上限, this.gameState.风险面板.警戒度));
                    this.gameState.风险面板.女警好感度 = Math.max(0, Math.min(100, this.gameState.风险面板.女警好感度));
                }
                if (update.当前目标) Object.assign(this.gameState.当前目标, update.当前目标);
                if (update.攻略记录) {
                    Object.assign(this.gameState.攻略记录, update.攻略记录);
                    // 限制最多15条
                    const entries = Object.entries(this.gameState.攻略记录);
                    if (entries.length > 15) {
                        this.gameState.攻略记录 = Object.fromEntries(entries.slice(-15));
                    }
                }
                if (update.成就) Object.assign(this.gameState.成就, update.成就);

                this.logDebug('info', '状态更新成功');
            } catch (e) {
                this.logDebug('error', '状态解析失败: ' + e.message);
            }
        },

        // ===== 上下文管理 =====
        getStoryContext(maxCount) {
            const recent = this.messages.slice(-maxCount);
            return recent.map(m => ({
                role: m.role === 'system' ? 'assistant' : m.role,
                content: m.content
            }));
        },

        // ===== 消息管理 =====
        getMessageRole(msg) {
            if (msg.role === 'assistant') return '旁白';
            if (msg.role === 'user') return this.playerName || '玩家';
            return '系统';
        },

        formatMessage(content) {
            if (!content) return '';
            return content.replace(/\n/g, '<br>');
        },

        editMessage(index) {
            this.editingIndex = index;
            this.editingContent = this.messages[index].content;
            this.editModalOpen = true;
        },

        confirmEdit() {
            if (this.editingIndex >= 0 && this.editingIndex < this.messages.length) {
                this.messages[this.editingIndex].content = this.editingContent;
                this.autoSave();
            }
            this.editModalOpen = false;
        },

        deleteMessage(index) {
            if (confirm('确定要删除这条消息吗？')) {
                this.messages.splice(index, 1);
                this.autoSave();
            }
        },

        async regenerateMessage() {
            if (this.generating) return;
            // 找到最后一条assistant消息
            const lastIdx = this.messages.length - 1;
            if (lastIdx < 0 || this.messages[lastIdx].role !== 'assistant') return;

            // 删除最后一条assistant消息
            this.messages.splice(lastIdx, 1);

            // 找到最后一条user消息
            let lastUserMsg = '';
            for (let i = this.messages.length - 1; i >= 0; i--) {
                if (this.messages[i].role === 'user') {
                    lastUserMsg = this.messages[i].content;
                    break;
                }
            }

            if (lastUserMsg) {
                await this.generateResponse(lastUserMsg);
            }
        },

        // ===== 面板切换 =====
        togglePanel(name) {
            this.activePanel = this.activePanel === name ? '' : name;
        },

        backToMenu() {
            if (confirm('返回主菜单？当前进度会自动保存。')) {
                this.autoSave();
                this.inGame = false;
                this.started = false;
            }
        },

        // ===== 存档系统 =====
        _getSaveData() {
            return {
                playerName: this.playerName,
                selectedModel: this.selectedModel,
                replyMinChars: this.replyMinChars,
                replyMaxChars: this.replyMaxChars,
                gameState: JSON.parse(JSON.stringify(this.gameState)),
                messages: this.messages.map(m => ({ id: m.id, role: m.role, content: m.content })),
                savedAt: new Date().toLocaleString('zh-CN')
            };
        },

        _loadSaveData(data) {
            if (data.playerName) this.playerName = data.playerName;
            if (data.selectedModel) this.selectedModel = data.selectedModel;
            if (data.replyMinChars) this.replyMinChars = data.replyMinChars;
            if (data.replyMaxChars) this.replyMaxChars = data.replyMaxChars;
            if (data.gameState) this.gameState = data.gameState;
            if (data.messages) this.messages = data.messages;
            this.started = true;
            this.inGame = true;
        },

        async autoSave() {
            try {
                const data = this._getSaveData();
                this._saveCache['auto'] = data;
                await window.dzmm.kv.put('fkss_auto_save', JSON.stringify(data));
                this.logDebug('info', '自动存档完成');
            } catch (e) {
                this.logDebug('warn', '自动存档失败: ' + e.message);
            }
        },

        async tryRestoreFromKV() {
            try {
                const auto = await window.dzmm.kv.get('fkss_auto_save');
                if (auto?.value) {
                    this._saveCache['auto'] = JSON.parse(auto.value);
                }
                // 预加载手动存档信息
                for (let i = 1; i <= 5; i++) {
                    try {
                        const s = await window.dzmm.kv.get('fkss_save_' + i);
                        if (s?.value) this._saveCache[i] = JSON.parse(s.value);
                    } catch (e) {}
                }
            } catch (e) {
                this.logDebug('warn', '恢复存档失败: ' + e.message);
            }
        },

        openSaveManager() { this.saveManagerOpen = true; },

        hasAutoSave() { return !!this._saveCache['auto']; },
        getAutoSaveInfo() {
            const s = this._saveCache['auto'];
            return s ? `${s.playerName} | ${s.gameState?.世界?.当前时间 || ''} | ${s.savedAt || ''}` : '空';
        },
        async loadAutoSave() {
            const s = this._saveCache['auto'];
            if (!s) return;
            this._loadSaveData(s);
            this.saveManagerOpen = false;
            this.scrollToBottom();
        },
        async deleteAutoSave() {
            if (!confirm('确定删除自动存档？')) return;
            delete this._saveCache['auto'];
            try { await window.dzmm.kv.delete('fkss_auto_save'); } catch (e) {}
        },

        hasSave(slot) { return !!this._saveCache[slot]; },
        getSaveInfo(slot) {
            const s = this._saveCache[slot];
            return s ? `${s.playerName} | ${s.gameState?.世界?.当前时间 || ''} | ${s.savedAt || ''}` : '空';
        },
        async saveToSlot(slot) {
            try {
                const data = this._getSaveData();
                this._saveCache[slot] = data;
                await window.dzmm.kv.put('fkss_save_' + slot, JSON.stringify(data));
                alert('保存成功！');
            } catch (e) {
                alert('保存失败: ' + e.message);
            }
        },
        async loadFromSlot(slot) {
            const s = this._saveCache[slot];
            if (!s) return;
            this._loadSaveData(s);
            this.saveManagerOpen = false;
            this.scrollToBottom();
        },
        async deleteSlot(slot) {
            if (!confirm('确定删除存档位 ' + slot + '？')) return;
            delete this._saveCache[slot];
            try { await window.dzmm.kv.delete('fkss_save_' + slot); } catch (e) {}
        },

        // ===== Debug =====
        logDebug(type, msg) {
            const time = new Date().toLocaleTimeString('zh-CN');
            this.debugLogs.unshift({ type, msg, time });
            if (this.debugLogs.length > 100) this.debugLogs.length = 100;
            if (type === 'error') console.error('[FKSS]', msg);
        },
        logPrompt(direction, content) {
            const time = new Date().toLocaleTimeString('zh-CN');
            this.debugPrompts.unshift({ direction, content, time });
            if (this.debugPrompts.length > 20) this.debugPrompts.length = 20;
        },

        startDragDebug(e) {
            const evt = e.touches ? e.touches[0] : e;
            if (evt.target.tagName === 'BUTTON') return;
            this._dragging = true;
            this._dragOffset = {
                x: evt.clientX - this.debugPos.x,
                y: evt.clientY - this.debugPos.y
            };
            const moveHandler = (e2) => {
                if (!this._dragging) return;
                const evt2 = e2.touches ? e2.touches[0] : e2;
                this.debugPos.x = Math.max(0, evt2.clientX - this._dragOffset.x);
                this.debugPos.y = Math.max(0, evt2.clientY - this._dragOffset.y);
            };
            const upHandler = () => {
                this._dragging = false;
                document.removeEventListener('mousemove', moveHandler);
                document.removeEventListener('mouseup', upHandler);
                document.removeEventListener('touchmove', moveHandler);
                document.removeEventListener('touchend', upHandler);
            };
            document.addEventListener('mousemove', moveHandler);
            document.addEventListener('mouseup', upHandler);
            document.addEventListener('touchmove', moveHandler, { passive: false });
            document.addEventListener('touchend', upHandler);
        },

        // ===== 工具 =====
        scrollToBottom() {
            setTimeout(() => {
                const el = document.querySelector('.messages-container');
                if (el) el.scrollTop = el.scrollHeight;
            }, 50);
        }
    });
});
