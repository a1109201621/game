/**
 * Tag 系统互动游戏 - 独立版
 * 
 * 玩家可以探索世界，遇到 NPC 后可以查看和修改其 Tag
 * 
 * 本版本为独立游戏，直接调用 OpenAI 兼容 API，无需依赖 dzmm 平台
 */

document.addEventListener('alpine:init', () => {
    Alpine.store('game', {
        // ==================== 基础状态 ====================
        loading: true,
        started: false,
        disabled: false,
        streaming: false,
        streamContent: '',
        generating: false,
        generatingContent: '',
        testing: false,
        testResult: null,

        // ==================== API 设置 ====================
        apiEndpoint: 'https://api.wutongsama.xyz',
        apiKey: '123',
        authType: 'bearer',
        customHeaderName: 'X-API-Key',
        model: '',
        manualModel: '',
        modelList: [],
        fetchingModels: false,
        useStream: 'true',

        // ==================== CORS 代理设置 ====================
        corsMode: 'none',
        customCorsProxy: '',

        // ==================== 生成参数 ====================
        maxContext: 1000000,
        maxReply: 64000,
        thinkingBudget: 10000,

        // ==================== 玩家配置 ====================
        player_name: '',
        input: '',

        // ==================== NPC 状态 ====================
        currentNpc: null,

        // ==================== 界面状态 ====================
        showTagPanel: false,
        tagChanged: false,
        messages: [],
        saveManagerOpen: false,
        settingsOpen: false,
        editModalOpen: false,
        editingIndex: -1,
        editingContent: '',

        // ==================== 存档状态 ====================
        hasSave: false,
        saveToast: false,
        saveToastMessage: '游戏已保存',

        // ==================== 自定义输入状态 ====================
        customInputs: {
            personality: false,
            profession: false,
            hobby: false,
            attitude: false,
            mood: false,
            clothing: false,
            bodyType: false,
            relationship: false,
            fetish: false
        },
        customValues: {
            personality: '',
            profession: '',
            hobby: '',
            attitude: '',
            mood: '',
            clothing: '',
            bodyType: '',
            relationship: '',
            fetish: ''
        },
        originalTags: null,

        // ==================== 预设选项 ====================
        presetOptions: {
            personality: ['开朗', '内向', '冷漠', '热情', '傲娇', '温柔', '病娇', '天然呆'],
            mood: ['普通', '高兴', '伤心', '害羞', '生气', '紧张', '兴奋'],
            profession: ['学生', '老师', 'OL', '偶像', '护士', '女仆', '画家', '作家'],
            hobby: ['阅读', '绘画', '音乐', '游戏', '运动', '烹饪', '独处', '社交'],
            attitude: ['友好', '冷淡', '好奇', '警惕', '亲密', '崇拜', '敌意'],
            clothing: ['校服', '制服', '便装', '和服', '女仆装', '旗袍', '运动装', '泳装', '性感内衣', '情趣制服'],
            bodyType: ['娇小', '丰满', '高挑', '运动型', '纤细', '巨乳', '贫乳', '长腿'],
            relationship: ['陌生人', '朋友', '暗恋对象', '恋人', '情人', '主人', '奴隶', '宠物'],
            fetish: ['抖M', '抖S', '露出癖', '恋足', '绝对服从', 'NTR', '催眠', '触手', '母乳', '束缚']
        },

        // ==================== Tag 分组定义 ====================
        tagGroups: [
            {
                name: '🧠 基础属性',
                tags: [
                    { key: 'personality', label: '性格' },
                    { key: 'mood', label: '心情' }
                ]
            },
            {
                name: '💼 社会属性',
                tags: [
                    { key: 'profession', label: '职业' },
                    { key: 'hobby', label: '爱好' },
                    { key: 'attitude', label: '对你的态度' }
                ]
            },
            {
                name: '👗 外观衣着',
                tags: [
                    { key: 'clothing', label: '衣着' },
                    { key: 'bodyType', label: '身体特征' }
                ]
            },
            {
                name: '💕 关系状态',
                tags: [
                    { key: 'relationship', label: '关系' }
                ]
            },
            {
                name: '🔥 性癖',
                tags: [
                    { key: 'fetish', label: '性癖' }
                ]
            }
        ],

        // ==================== Debug 面板 ====================
        debugPanel: {
            open: false,
            lastSent: '',
            rawResponse: '',
            parsedContent: '',
            responseStatus: '',
            errors: []
        },

        // ==================== 初始化 ====================
        init() {
            this.loadSettings();
            const validModes = ['none', 'corsproxy', 'corsanywhere', 'allorigins', 'custom'];
            if (!validModes.includes(this.corsMode)) {
                this.corsMode = 'corsproxy';
                this.saveSettings();
            }
            this.checkSave();
            setTimeout(() => {
                if (this.loading) {
                    this.loading = false;
                }
            }, 2000);
        },

        skipLoading() {
            this.loading = false;
        },

        getActiveModel() {
            return this.manualModel.trim() || this.model;
        },

        // ==================== CORS 代理 ====================
        getCorsProxyUrl() {
            switch (this.corsMode) {
                case 'corsproxy':
                    return 'https://corsproxy.io/?';
                case 'corsanywhere':
                    return 'https://cors-anywhere.herokuapp.com/';
                case 'allorigins':
                    return 'https://api.allorigins.win/raw?url=';
                case 'custom':
                    return this.customCorsProxy || '';
                case 'none':
                default:
                    return '';
            }
        },

        wrapUrlWithProxy(url) {
            const proxyUrl = this.getCorsProxyUrl();
            if (!proxyUrl) return url;
            if (this.corsMode === 'corsanywhere') {
                return proxyUrl + url;
            }
            return proxyUrl + encodeURIComponent(url);
        },

        // ==================== 设置管理 ====================
        resetSettings() {
            if (confirm('确定要重置所有设置吗？这将清除所有保存的配置（不影响存档）。')) {
                localStorage.removeItem('tag_system_settings');
                this.apiEndpoint = 'https://api.wutongsama.xyz';
                this.apiKey = '123';
                this.authType = 'bearer';
                this.customHeaderName = 'X-API-Key';
                this.model = '';
                this.manualModel = '';
                this.modelList = [];
                this.useStream = 'true';
                this.corsMode = 'none';
                this.customCorsProxy = '';
                this.maxContext = 1000000;
                this.maxReply = 64000;
                this.thinkingBudget = 10000;
                this.player_name = '';
                alert('设置已重置！');
            }
        },

        loadSettings() {
            try {
                const settings = localStorage.getItem('tag_system_settings');
                if (settings) {
                    const parsed = JSON.parse(settings);
                    const keys = ['apiEndpoint', 'apiKey', 'authType', 'customHeaderName', 'model', 'manualModel', 'modelList', 'maxContext', 'maxReply', 'thinkingBudget', 'player_name', 'useStream', 'corsMode', 'customCorsProxy'];
                    keys.forEach(key => {
                        if (parsed[key] !== undefined) {
                            this[key] = parsed[key];
                        }
                    });
                }
            } catch (e) {
                this.logError('加载设置失败: ' + e.message);
            }
        },

        saveSettings() {
            try {
                const settings = {
                    apiEndpoint: this.apiEndpoint,
                    apiKey: this.apiKey,
                    authType: this.authType,
                    customHeaderName: this.customHeaderName,
                    model: this.model,
                    manualModel: this.manualModel,
                    modelList: this.modelList,
                    maxContext: this.maxContext,
                    maxReply: this.maxReply,
                    thinkingBudget: this.thinkingBudget,
                    player_name: this.player_name,
                    useStream: this.useStream,
                    corsMode: this.corsMode,
                    customCorsProxy: this.customCorsProxy
                };
                localStorage.setItem('tag_system_settings', JSON.stringify(settings));
            } catch (e) {
                this.logError('保存设置失败: ' + e.message);
            }
        },

        // ==================== API 认证 ====================
        getAuthHeaders() {
            const headers = {
                'Content-Type': 'application/json'
            };

            switch (this.authType) {
                case 'bearer':
                    if (this.apiKey) {
                        headers['Authorization'] = `Bearer ${this.apiKey}`;
                    }
                    break;
                case 'apikey':
                    if (this.apiKey) {
                        headers['api-key'] = this.apiKey;
                        headers['x-api-key'] = this.apiKey;
                    }
                    break;
                case 'basic':
                    if (this.apiKey) {
                        headers['Authorization'] = `Basic ${btoa(this.apiKey)}`;
                    }
                    break;
                case 'custom':
                    if (this.apiKey && this.customHeaderName) {
                        headers[this.customHeaderName] = this.apiKey;
                    }
                    break;
                case 'none':
                default:
                    break;
            }

            return headers;
        },

        // ==================== 测试连接 ====================
        async testConnection() {
            this.testing = true;
            this.testResult = null;

            const startTime = Date.now();
            const targetUrl = `${this.apiEndpoint}/v1/models`;
            const fetchUrl = this.wrapUrlWithProxy(targetUrl);

            try {
                this.debugPanel.lastSent = `GET ${targetUrl}\nProxy Mode: ${this.corsMode}\nActual Fetch URL: ${fetchUrl}`;

                const response = await fetch(fetchUrl, {
                    method: 'GET',
                    headers: this.getAuthHeaders()
                });

                const elapsed = Date.now() - startTime;
                const responseText = await response.text();

                this.debugPanel.responseStatus = `状态: ${response.status} ${response.statusText}\n耗时: ${elapsed}ms\n代理: ${this.corsMode}`;
                this.debugPanel.rawResponse = responseText.substring(0, 1500);

                if (response.ok) {
                    try {
                        const data = JSON.parse(responseText);
                        const modelCount = data.data?.length || 0;
                        this.testResult = {
                            success: true,
                            message: `✓ 连接成功! 找到 ${modelCount} 个模型 (${elapsed}ms)`
                        };
                    } catch {
                        this.testResult = {
                            success: true,
                            message: `✓ 连接成功! (${elapsed}ms)`
                        };
                    }
                } else {
                    this.testResult = {
                        success: false,
                        message: `✗ HTTP ${response.status}: ${response.statusText}`
                    };
                    this.logError(`连接测试失败: HTTP ${response.status}`);
                }
            } catch (e) {
                const elapsed = Date.now() - startTime;
                let suggestion = '';
                if (e.message.includes('Failed to fetch')) {
                    suggestion = '\n\n💡 建议：\n1. 点击"重置设置"清除旧数据\n2. 确保CORS代理设为"corsproxy.io"\n3. 检查API地址是否正确';
                }
                this.testResult = {
                    success: false,
                    message: `✗ 连接失败: ${e.message}${suggestion}`
                };
                this.logError(`连接测试异常: ${e.message}`);
                this.debugPanel.responseStatus = `错误: ${e.message}\n耗时: ${elapsed}ms\nProxy: ${this.corsMode}\nURL: ${fetchUrl}`;
            } finally {
                this.testing = false;
            }
        },

        // ==================== 获取模型列表 ====================
        async fetchModels() {
            this.fetchingModels = true;
            this.testResult = null;

            const targetUrl = `${this.apiEndpoint}/v1/models`;
            const fetchUrl = this.wrapUrlWithProxy(targetUrl);

            try {
                this.debugPanel.lastSent = `GET ${targetUrl}\nProxy: ${this.corsMode}\nFetch URL: ${fetchUrl}`;

                const response = await fetch(fetchUrl, {
                    method: 'GET',
                    headers: this.getAuthHeaders()
                });

                const responseText = await response.text();
                this.debugPanel.rawResponse = responseText.substring(0, 1500);

                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                }

                const data = JSON.parse(responseText);

                if (data.data && Array.isArray(data.data)) {
                    this.modelList = data.data.map(m => m.id || m.name || m);
                } else if (Array.isArray(data)) {
                    this.modelList = data.map(m => typeof m === 'string' ? m : (m.id || m.name));
                } else if (data.models && Array.isArray(data.models)) {
                    this.modelList = data.models.map(m => typeof m === 'string' ? m : (m.id || m.name));
                } else {
                    throw new Error('无法解析模型列表格式');
                }

                if (this.modelList.length > 0 && !this.model) {
                    this.model = this.modelList[0];
                }

                this.testResult = {
                    success: true,
                    message: `✓ 成功获取 ${this.modelList.length} 个模型`
                };

                this.saveSettings();
            } catch (e) {
                this.logError('获取模型列表失败: ' + e.message);
                let suggestion = '';
                if (e.message.includes('Failed to fetch')) {
                    suggestion = '\n建议: 点击"重置设置"后重试';
                }
                this.testResult = {
                    success: false,
                    message: `✗ 获取失败: ${e.message}${suggestion}`
                };
            } finally {
                this.fetchingModels = false;
            }
        },

        // ==================== 发送 API 请求 ====================
        async sendToAPI(messages) {
            const activeModel = this.getActiveModel();
            const isStream = this.useStream === 'true';

            const requestBody = {
                model: activeModel,
                messages: messages,
                temperature: 1,
                frequency_penalty: 0,
                presence_penalty: 0,
                top_p: 1,
                max_tokens: Number(this.maxReply) || 4096,
                stream: isStream,
                stop: ['<end>']
            };

            if (this.thinkingBudget > 0) {
                requestBody.thinking = {
                    type: "enabled",
                    budget_tokens: Number(this.thinkingBudget)
                };
            }

            this.debugPanel.lastSent = JSON.stringify(requestBody, null, 2);

            const targetUrl = `${this.apiEndpoint}/v1/chat/completions`;
            const fetchUrl = this.wrapUrlWithProxy(targetUrl);

            const response = await fetch(fetchUrl, {
                method: 'POST',
                headers: this.getAuthHeaders(),
                body: JSON.stringify(requestBody)
            });

            this.debugPanel.responseStatus = `POST ${targetUrl}\n状态: ${response.status} ${response.statusText}\n代理: ${this.corsMode}`;

            if (!response.ok) {
                const errorText = await response.text();
                this.debugPanel.rawResponse = errorText;
                throw new Error(`HTTP ${response.status}: ${response.statusText}\n${errorText.substring(0, 300)}`);
            }

            return response;
        },

        // ==================== 响应解析 ====================
        extractContentFromResponse(data) {
            const paths = [
                () => data.choices?.[0]?.message?.content,
                () => data.choices?.[0]?.delta?.content,
                () => data.message?.content,
                () => data.content,
                () => data.response,
                () => data.text,
                () => data.output,
                () => data.result,
            ];

            for (const path of paths) {
                try {
                    const content = path();
                    if (content && typeof content === 'string') {
                        return content;
                    }
                } catch (e) { }
            }

            return null;
        },

        async handleStreamResponse(response) {
            let fullContent = '';
            const reader = response.body.getReader();
            const decoder = new TextDecoder();
            let buffer = '';

            this.debugPanel.rawResponse = '';

            try {
                while (true) {
                    const { done, value } = await reader.read();
                    if (done) break;

                    const chunk = decoder.decode(value, { stream: true });
                    buffer += chunk;

                    this.debugPanel.rawResponse += chunk;
                    if (this.debugPanel.rawResponse.length > 3000) {
                        this.debugPanel.rawResponse = this.debugPanel.rawResponse.substring(0, 3000) + '\n...(截断)';
                    }

                    const lines = buffer.split('\n');
                    buffer = lines.pop() || '';

                    for (const line of lines) {
                        const trimmedLine = line.trim();
                        if (!trimmedLine) continue;

                        if (trimmedLine.startsWith('data: ')) {
                            const data = trimmedLine.slice(6).trim();
                            if (data === '[DONE]') continue;

                            try {
                                const parsed = JSON.parse(data);
                                const content = this.extractContentFromResponse(parsed);
                                if (content) {
                                    fullContent += content;
                                    this.generatingContent = fullContent;
                                }
                            } catch (e) { }
                        } else {
                            try {
                                const parsed = JSON.parse(trimmedLine);
                                const content = this.extractContentFromResponse(parsed);
                                if (content) {
                                    fullContent += content;
                                    this.generatingContent = fullContent;
                                }
                            } catch (e) { }
                        }
                    }

                    this.scrollToBottom();
                }

                if (buffer.trim() && buffer.startsWith('data: ')) {
                    const data = buffer.slice(6).trim();
                    if (data && data !== '[DONE]') {
                        try {
                            const parsed = JSON.parse(data);
                            const content = this.extractContentFromResponse(parsed);
                            if (content) fullContent += content;
                        } catch (e) { }
                    }
                }

            } catch (e) {
                this.logError('流读取错误: ' + e.message);
                throw e;
            }

            this.debugPanel.parsedContent = fullContent.substring(0, 2000);
            return fullContent;
        },

        async handleNonStreamResponse(response) {
            const responseText = await response.text();
            this.debugPanel.rawResponse = responseText.substring(0, 3000);

            try {
                const data = JSON.parse(responseText);
                const content = this.extractContentFromResponse(data);

                if (content) {
                    this.debugPanel.parsedContent = content.substring(0, 2000);
                    return content;
                }

                // 深度搜索
                const findContent = (obj, depth = 0) => {
                    if (depth > 5 || !obj) return null;
                    if (typeof obj === 'string' && obj.length > 50) return obj;
                    if (Array.isArray(obj)) {
                        for (const item of obj) {
                            const found = findContent(item, depth + 1);
                            if (found) return found;
                        }
                    } else if (typeof obj === 'object') {
                        for (const key of Object.keys(obj)) {
                            const found = findContent(obj[key], depth + 1);
                            if (found) return found;
                        }
                    }
                    return null;
                };

                const foundContent = findContent(data);
                if (foundContent) {
                    this.debugPanel.parsedContent = foundContent.substring(0, 2000);
                    return foundContent;
                }

                throw new Error('无法从响应中提取内容');
            } catch (e) {
                this.logError('响应解析失败: ' + e.message);
                throw e;
            }
        },

        // ==================== Tag 系统逻辑 ====================

        /**
         * 将 Tag 值格式化为字符串（数组 join，单值直接返回）
         */
        formatTagValue(tagType) {
            if (!this.currentNpc) return '';
            const val = this.currentNpc.tags[tagType];
            if (Array.isArray(val)) return val.join('、');
            return val || '';
        },

        /**
         * 切换 Tag 选中状态（多选）
         */
        toggleTag(tagType, value) {
            if (!this.currentNpc) return;
            let arr = this.currentNpc.tags[tagType];
            if (!Array.isArray(arr)) {
                arr = arr ? [arr] : [];
            }
            const idx = arr.indexOf(value);
            if (idx >= 0) {
                arr.splice(idx, 1);
            } else {
                arr.push(value);
            }
            this.currentNpc.tags[tagType] = [...arr];
            this.onTagChange();
        },

        /**
         * 检查某个 Tag 值是否被选中
         */
        isTagSelected(tagType, value) {
            if (!this.currentNpc) return false;
            const arr = this.currentNpc.tags[tagType];
            if (Array.isArray(arr)) return arr.includes(value);
            return arr === value;
        },

        /**
         * 应用自定义 Tag 值（新版：追加到数组）
         */
        applyCustomTag(tagType) {
            const value = this.customValues[tagType]?.trim();
            if (value && this.currentNpc) {
                let arr = this.currentNpc.tags[tagType];
                if (!Array.isArray(arr)) {
                    arr = arr ? [arr] : [];
                }
                if (!arr.includes(value)) {
                    arr.push(value);
                }
                this.currentNpc.tags[tagType] = [...arr];
                this.customValues[tagType] = '';
                this.customInputs[tagType] = false;
                this.onTagChange();
            } else {
                this.customInputs[tagType] = false;
            }
        },

        /**
         * 生成系统提示词
         */
        createSystemPrompt() {
            let npcInfo = '';
            if (this.currentNpc) {
                const t = (key) => this.formatTagValue(key) || '无';
                npcInfo = `
【当前NPC信息】
姓名：${this.currentNpc.name}
性格：${t('personality')}
心情：${t('mood')}
职业：${t('profession')}
爱好：${t('hobby')}
对${this.player_name}的态度：${t('attitude')}
衣着：${t('clothing')}
身体特征：${t('bodyType')}
与${this.player_name}的关系：${t('relationship')}
性癖：${t('fetish')}

【NPC行为规则】
NPC的言行必须完全符合上述Tag设定：
- 性格决定说话方式和反应模式
- 职业影响知识背景和话题
- 爱好是经常提起的兴趣
- 态度决定对玩家的亲疏
- 心情影响当前情绪状态
- 衣着决定NPC当前穿着的服装，需要在描写中自然体现
- 身体特征决定NPC的外形，描写中应体现
- 关系决定NPC与玩家之间的关系层次和互动方式
- 性癖决定NPC的特殊偏好，在适当时机自然体现`;
            }

            return `你是一个互动小说游戏的叙述者AI。玩家名叫${this.player_name}，拥有特殊能力可以修改NPC的Tag。

【回复格式要求】
每次回复必须严格遵循此格式：

###STATE
{"npc_name":"NPC名字或null","mood":"心情","personality":"性格","profession":"职业","hobby":"爱好","attitude":"态度","clothing":"衣着","bodyType":"身体特征","relationship":"关系","fetish":"性癖","summary":"简短总结"}
###END
叙述内容

【格式规则】
1. 前三行必须是 ###STATE、JSON、###END
2. JSON 必须在一行内
3. 如果场景中出现新NPC，填写npc_name和其他属性；如果只是环境描述，npc_name填null
4. 第4行开始是叙述内容
5. NPC名字要有寓意，禁止"小xx"、"阿xx"或叠词
6. 各字段可填一个或多个值（用顿号分隔）
${npcInfo}

【场景描写要求】
- 描写要生动有画面感
- 使用*包围动作和环境描写
- 对话用引号包围
- 如果玩家想去某地或找某人，自然地引导相遇
- 玩家的Tag修改后，NPC会自然地表现出来，不需要特意说明
- 每次回复的正文部分不少于600字
- NPC的衣着、身体特征、关系和性癖在描写中自然体现

【禁止事项】
❌ 不要提及 Tag 系统的存在
❌ 不要让NPC知道自己被设定
❌ 保持沉浸感`;
        },

        // ==================== 游戏流程 ====================

        /**
         * 开始游戏
         */
        async start() {
            this.started = true;
            this.saveSettings();
            this.messages = [];
            this.currentNpc = null;

            // 显示开场白
            const openingText = `阳光温暖地洒落在街道上，周围是熙熙攘攘的人群。你突然意识到，自己拥有一种特殊的能力——可以看到并修改他人内心深处的"Tag"。

这里是一座繁华的都市。向北是商业街，向东是学园区，向南是住宅区，向西是公园。`;

            this.messages.push({
                id: Date.now(),
                role: 'assistant',
                speaker: '旁白',
                content: openingText
            });

            this.scrollToBottom();
        },

        /**
         * 发送消息
         */
        async send() {
            if (!this.input.trim() || this.disabled || this.generating) return;

            const userMessage = this.input.trim();
            this.input = '';

            this.messages.push({
                id: Date.now(),
                role: 'user',
                content: userMessage
            });

            this.scrollToBottom();
            await this.requestAIResponse(userMessage);
        },

        /**
         * 开启自定义输入
         */
        openCustomInput(tagType) {
            this.customInputs[tagType] = true;
            this.customValues[tagType] = '';
            setTimeout(() => {
                const input = document.querySelector(`#custom-input-${tagType}`);
                if (input) input.focus();
            }, 50);
        },

        /**
         * Tag 变更回调
         */
        onTagChange() {
            this.tagChanged = true;
        },

        /**
         * 应用 Tag 修改，让 AI 生成反应
         */
        async applyTagChanges() {
            if (!this.currentNpc || !this.tagChanged) return;

            this.tagChanged = false;
            this.showTagPanel = false;

            const t = (key) => this.formatTagValue(key) || '无';
            const prompt = `（系统：玩家使用能力修改了${this.currentNpc.name}的Tag。现在她的属性变为：性格=${t('personality')}，心情=${t('mood')}，职业=${t('profession')}，爱好=${t('hobby')}，态度=${t('attitude')}，衣着=${t('clothing')}，身体特征=${t('bodyType')}，关系=${t('relationship')}，性癖=${t('fetish')}。请根据新的Tag描写${this.currentNpc.name}的变化和反应，她本人不知道自己被修改了，但性格、外表和行为会自然地发生变化）`;

            await this.requestAIResponse(prompt);
        },

        /**
         * 请求 AI 回复
         */
        async requestAIResponse(userMessage) {
            this.disabled = true;
            this.generating = true;
            this.generatingContent = '';

            try {
                // 构建 messages 数组
                const apiMessages = [
                    { role: 'system', content: this.createSystemPrompt() }
                ];

                // 添加历史消息（考虑上下文长度限制）
                let contextLength = this.createSystemPrompt().length;
                const historyMessages = [];

                for (let i = this.messages.length - 1; i >= 0; i--) {
                    const msg = this.messages[i];
                    const msgLength = msg.content.length;
                    if (contextLength + msgLength > this.maxContext * 0.8) break;
                    historyMessages.unshift({
                        role: msg.role,
                        content: msg.content
                    });
                    contextLength += msgLength;
                }

                apiMessages.push(...historyMessages);

                if (userMessage) {
                    apiMessages.push({ role: 'user', content: userMessage });
                }

                const response = await this.sendToAPI(apiMessages);

                let fullContent = '';

                if (this.useStream === 'true') {
                    fullContent = await this.handleStreamResponse(response);
                } else {
                    fullContent = await this.handleNonStreamResponse(response);
                }

                if (fullContent) {
                    const parsed = this.parseAIResponse(fullContent);

                    if (parsed.ready) {
                        this.updateGameState(parsed.state);
                    }

                    this.messages.push({
                        id: Date.now(),
                        role: 'assistant',
                        speaker: this.currentNpc?.name || '旁白',
                        content: fullContent
                    });

                    this.autoSave();
                } else {
                    throw new Error('未能获取有效的响应内容');
                }

            } catch (error) {
                console.error('AI 请求失败:', error);
                this.logError('AI 请求失败: ' + error.message);
                this.messages.push({
                    id: Date.now(),
                    role: 'assistant',
                    speaker: '系统',
                    content: `【系统错误】生成失败: ${error.message}\n\n请检查：\n1. 点击"重置设置"清除旧数据\n2. 确保CORS代理设为"corsproxy.io"\n3. 尝试禁用"流式响应"\n\n可打开Debug面板查看详情。`
                });
            } finally {
                this.disabled = false;
                this.generating = false;
                this.generatingContent = '';
                this.scrollToBottom();
            }
        },

        /**
         * 解析 AI 回复
         */
        parseAIResponse(content) {
            const stateMarker = '###STATE';
            const endMarker = '###END';
            const stateIndex = content.indexOf(stateMarker);
            const endIndex = content.indexOf(endMarker, stateIndex + stateMarker.length);

            if (stateIndex === -1 || endIndex === -1) {
                return { ready: false };
            }

            const jsonRaw = content.slice(stateIndex + stateMarker.length, endIndex).trim();

            try {
                const state = JSON.parse(jsonRaw);
                let dialogue = content.slice(endIndex + endMarker.length).trim();
                return { ready: true, state, dialogue };
            } catch (error) {
                console.warn('状态解析失败:', error);
                return { ready: false };
            }
        },

        /**
         * 格式化消息内容（用于显示）
         */
        formatMessage(content) {
            if (!content) return content;

            // 移除 ###STATE...###END 块
            content = content.replace(/###STATE[\s\S]*?###END/g, '');

            // 将换行转为 <br>
            content = content.replace(/\n/g, '<br>');

            // 将 *text* 转换为带颜色的动作描写
            content = content.replace(/\*([^*]+)\*/g, '<font color=#00BFFF>$1</font>');

            // 将 「text」或 "text" 转换为带样式的对话
            content = content.replace(/「([^」]+)」/g, '<span style="color:#fbbf24">「$1」</span>');
            content = content.replace(/"([^"]+)"/g, '<span style="color:#fbbf24">"$1"</span>');

            return content;
        },

        /**
         * 将状态值转为数组
         */
        toTagArray(value, fallback) {
            if (!value || value === 'null' || value === '无') return fallback ? [fallback] : [];
            if (Array.isArray(value)) return value;
            return value.split(/[、,，]/).map(s => s.trim()).filter(Boolean);
        },

        /**
         * 更新游戏状态
         */
        updateGameState(state) {
            if (state.npc_name && state.npc_name !== 'null') {
                if (!this.currentNpc || this.currentNpc.name !== state.npc_name) {
                    this.currentNpc = {
                        name: state.npc_name,
                        tags: {
                            personality: this.toTagArray(state.personality, '普通'),
                            mood: this.toTagArray(state.mood, '普通'),
                            profession: this.toTagArray(state.profession, '路人'),
                            hobby: this.toTagArray(state.hobby, '散步'),
                            attitude: this.toTagArray(state.attitude, '友好'),
                            clothing: this.toTagArray(state.clothing, '便装'),
                            bodyType: this.toTagArray(state.bodyType),
                            relationship: this.toTagArray(state.relationship, '陌生人'),
                            fetish: this.toTagArray(state.fetish)
                        }
                    };
                } else {
                    if (state.mood) this.currentNpc.tags.mood = this.toTagArray(state.mood, '普通');
                }
            }
        },

        // ==================== 消息管理 ====================

        editMessage(index) {
            this.editingIndex = index;
            this.editingContent = this.messages[index].content;
            this.editModalOpen = true;
        },

        confirmEdit() {
            if (this.editingIndex >= 0 && this.editingIndex < this.messages.length) {
                this.messages[this.editingIndex].content = this.editingContent;
                this.autoSave();
            }
            this.editModalOpen = false;
            this.editingIndex = -1;
            this.editingContent = '';
        },

        deleteMessage(index) {
            if (confirm('确定要删除这条消息吗？')) {
                this.messages.splice(index, 1);
                this.autoSave();
            }
        },

        async regenerateMessage() {
            if (this.messages.length === 0 || this.generating) return;

            if (this.messages[this.messages.length - 1].role === 'assistant') {
                this.messages.pop();
            }

            let trigger = '请继续描写场景';
            for (let i = this.messages.length - 1; i >= 0; i--) {
                if (this.messages[i].role === 'user') {
                    trigger = this.messages[i].content;
                    break;
                }
            }

            await this.requestAIResponse(trigger);
        },

        // ==================== 存档系统 ====================

        getSaveKey(slot) {
            return `tag_system_save_${slot}`;
        },

        checkSave() {
            this.hasSave = false;
            for (let i = 1; i <= 5; i++) {
                if (localStorage.getItem(this.getSaveKey(i)) !== null) {
                    this.hasSave = true;
                    break;
                }
            }
        },

        hasSaveSlot(slot) {
            return localStorage.getItem(this.getSaveKey(slot)) !== null;
        },

        getSaveInfo(slot) {
            const data = localStorage.getItem(this.getSaveKey(slot));
            if (!data) return '（空）';
            try {
                const save = JSON.parse(data);
                const date = new Date(save.timestamp).toLocaleString();
                return `${save.player_name} · ${save.currentNpc?.name || '探索中'} · ${date}`;
            } catch {
                return '（数据损坏）';
            }
        },

        saveToSlot(slot) {
            try {
                const saveData = {
                    timestamp: Date.now(),
                    player_name: this.player_name,
                    currentNpc: this.currentNpc,
                    messages: this.messages,
                    settings: {
                        apiEndpoint: this.apiEndpoint,
                        apiKey: this.apiKey,
                        authType: this.authType,
                        model: this.model,
                        manualModel: this.manualModel,
                        maxContext: this.maxContext,
                        maxReply: this.maxReply,
                        thinkingBudget: this.thinkingBudget,
                        useStream: this.useStream,
                        corsMode: this.corsMode,
                        customCorsProxy: this.customCorsProxy
                    }
                };
                localStorage.setItem(this.getSaveKey(slot), JSON.stringify(saveData));
                this.hasSave = true;

                this.saveToastMessage = `已保存到存档位 ${slot}`;
                this.saveToast = true;
                setTimeout(() => {
                    this.saveToast = false;
                }, 2000);
            } catch (e) {
                this.logError('保存失败: ' + e.message);
                alert('保存失败: ' + e.message);
            }
        },

        loadFromSlot(slot) {
            try {
                const data = localStorage.getItem(this.getSaveKey(slot));
                if (!data) {
                    alert('存档为空！');
                    return;
                }

                const save = JSON.parse(data);
                this.player_name = save.player_name || this.player_name;
                this.currentNpc = save.currentNpc || null;
                this.messages = save.messages || [];

                if (save.settings) {
                    const settingsKeys = ['apiEndpoint', 'apiKey', 'authType', 'model', 'manualModel', 'maxContext', 'maxReply', 'thinkingBudget', 'useStream', 'corsMode', 'customCorsProxy'];
                    settingsKeys.forEach(key => {
                        if (save.settings[key] !== undefined) {
                            this[key] = save.settings[key];
                        }
                    });
                }

                this.started = true;
                this.saveManagerOpen = false;
                this.scrollToBottom();

                this.saveToastMessage = '存档读取成功';
                this.saveToast = true;
                setTimeout(() => {
                    this.saveToast = false;
                }, 2000);
            } catch (e) {
                this.logError('读取失败: ' + e.message);
                alert('读取失败: ' + e.message);
            }
        },

        deleteSlot(slot) {
            if (confirm('确定要删除这个存档吗？')) {
                localStorage.removeItem(this.getSaveKey(slot));
                this.checkSave();

                this.saveToastMessage = `存档位 ${slot} 已删除`;
                this.saveToast = true;
                setTimeout(() => {
                    this.saveToast = false;
                }, 2000);
            }
        },

        autoSave() {
            try {
                const autoSaveData = {
                    timestamp: Date.now(),
                    player_name: this.player_name,
                    currentNpc: this.currentNpc,
                    messages: this.messages
                };
                localStorage.setItem('tag_system_autosave', JSON.stringify(autoSaveData));
            } catch (e) { }
        },

        // ==================== UI 控制 ====================

        openSaveManager() {
            this.saveManagerOpen = true;
        },

        openSettings() {
            this.settingsOpen = true;
        },

        backToMenu() {
            if (confirm('确定要返回主菜单吗？未保存的进度将丢失。')) {
                this.started = false;
                this.saveSettings();
            }
        },

        scrollToBottom() {
            setTimeout(() => {
                const container = document.querySelector('.chat-messages');
                if (container) {
                    container.scrollTop = container.scrollHeight;
                }
            }, 50);
        },

        // ==================== Debug ====================

        logError(message) {
            const timestamp = new Date().toLocaleTimeString();
            const entry = `[${timestamp}] ${message}`;
            this.debugPanel.errors.unshift(entry);
            if (this.debugPanel.errors.length > 50) {
                this.debugPanel.errors = this.debugPanel.errors.slice(0, 50);
            }
            console.error(entry);
        },

        clearDebugLogs() {
            this.debugPanel.lastSent = '';
            this.debugPanel.rawResponse = '';
            this.debugPanel.parsedContent = '';
            this.debugPanel.responseStatus = '';
            this.debugPanel.errors = [];
        },

        exportDebugLogs() {
            const logs = {
                timestamp: new Date().toISOString(),
                settings: {
                    apiEndpoint: this.apiEndpoint,
                    authType: this.authType,
                    model: this.getActiveModel(),
                    useStream: this.useStream,
                    corsMode: this.corsMode,
                    maxContext: this.maxContext,
                    maxReply: this.maxReply,
                    thinkingBudget: this.thinkingBudget
                },
                lastSent: this.debugPanel.lastSent,
                rawResponse: this.debugPanel.rawResponse,
                parsedContent: this.debugPanel.parsedContent,
                responseStatus: this.debugPanel.responseStatus,
                errors: this.debugPanel.errors
            };

            const blob = new Blob([JSON.stringify(logs, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `tag_system_debug_${Date.now()}.json`;
            a.click();
            URL.revokeObjectURL(url);
        }
    });

    queueMicrotask(() => Alpine.store('game').init?.());
});
