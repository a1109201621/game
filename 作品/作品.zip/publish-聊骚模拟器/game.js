if (window.parent !== window) {
    window.parent.postMessage('iframe:content-ready', '*');
}

const dzmmReady = new Promise((resolve) => {
    window.addEventListener('message', function handler(event) {
        if (event.data?.type === 'dzmm:ready') {
            window.removeEventListener('message', handler);
            resolve();
        }
    });

    // 设置超时自动resolve，防止无限等待
    setTimeout(() => {
        resolve();
    }, 5000);
});

document.addEventListener('alpine:init', () => {
    Alpine.store('chat', {
        loading: true,
        started: false,
        sending: false,
        typing: false,
        money: 10000,
        affection: 0,
        showRedPacket: false,
        showGift: false,
        showModelSelect: false,
        drawing: false,
        redPacketAmount: 100,
        redPacketMessage: '',
        giftName: '',
        giftPrice: 100,
        giftMessage: '',

        // AI生成相关
        generating: false,
        customRequirement: '',

        model: 'nalang-xl-0826',
        modelList: [
            { value: 'nalang-xl-0826', label: 'nalang-xl-0826 — 最强模型（32K 上下文）' },
            { value: 'x-apex-0212', label: 'Apex-Sigma-0212 — 文笔精致，角色刻画深入' },
            { value: 'x-apex-neo', label: 'Apex-Neo-0213 — 叙事细腻，感官描写丰富' },
            { value: 'x-apex-flux-0217', label: 'Apex-Flux-0217 — 节奏明快，场景描写生动' },
            { value: 'nalang-turbo-0826', label: 'nalang-turbo-0826 — 快速经济（32K 上下文）' },
            { value: 'nalang-medium-0826', label: 'nalang-medium-0826 — 平衡性能（32K 上下文）' },
            { value: 'nalang-max-0826', label: 'nalang-max-0826 — 高质量（32K 上下文）' },
        ],

        // 二次元绘画风格（固定）
        animePositive: 'masterpiece, best quality, year2025, anime style, official art style, 1.55::artist:nobusawa_osamu ::, 1.35::artist:tedain ::, 0.95::artist:asou_(asabu202) ::, 1.05::Artist:kcccc ::, 1.05::Artist:nixeu ::, 0.75::Artist:rella ::, desaturated, muted colors, pastel palette, soft lighting, low contrast, gentle shading, matte background, overcast sky, natural lighting, cinematic atmosphere, soft focus, delicate details, ambient occlusion, no text',
        animeNegative: 'worst quality, low quality, vibrant colors, neon, saturated, high contrast, vivid, colorful, pop art, fluorescent, hard lighting, harsh shadows, glare, bloom, photorealistic, 3D render, realistic, lowres, signature, username, bad id, bad twitter id, english commentary, logo, bad hands, mutated hands, mammal, anthro, furry, text',

        // 部位关键词 → SD提示词tag映射
        bodyPartPrompts: {
            // === 胸部 ===
            '胸': 'close-up, breasts focus, cleavage, large breasts, collarbone',
            '奶': 'close-up, breasts focus, cleavage, large breasts',
            '乳': 'close-up, breasts, nipples, topless, areolae',
            '咪咪': 'close-up, breasts focus, cleavage, large breasts',
            '波': 'close-up, breasts focus, cleavage, large breasts',
            '乳沟': 'close-up, cleavage focus, breasts, deep cleavage',
            '胸口': 'close-up, collarbone, upper body, cleavage, breasts',
            '奶子': 'close-up, breasts focus, large breasts, bouncing breasts',
            // === 脚/腿 ===
            '脚': 'close-up, feet focus, barefoot, toes, sole, foot arch',
            '足': 'close-up, feet focus, barefoot, toes, foot sole, ankle',
            '丝袜': 'close-up, feet, thighhighs, pantyhose, legs, high heels',
            '腿': 'close-up, legs focus, thighs, bare legs, long legs',
            '美腿': 'close-up, legs focus, thighs, bare legs, thigh gap, slender legs',
            '大腿': 'close-up, thighs focus, thick thighs, bare legs, thigh gap',
            '小腿': 'close-up, calves, lower legs, bare legs, ankle',
            '脚趾': 'close-up, toes focus, barefoot, feet, toe spread',
            '脚底': 'close-up, sole focus, barefoot, foot sole, toes',
            '高跟鞋': 'close-up, high heels, legs, feet, elegant pose',
            '黑丝': 'close-up, black pantyhose, legs, thighhighs, feet',
            '白丝': 'close-up, white thighhighs, legs, bare skin, garter',
            // === 腋下 ===
            '腋': 'close-up, armpit focus, armpits, arms up, smooth skin',
            '腋下': 'close-up, armpit focus, armpits, arms up, smooth skin, bare shoulders',
            // === 腹部/腰 ===
            '肚': 'close-up, navel focus, bare midriff, stomach, navel, slim waist',
            '腹': 'close-up, navel focus, bare midriff, stomach, navel, toned belly',
            '小腹': 'close-up, navel focus, bare midriff, lower abdomen, navel, slim waist',
            '肚脐': 'close-up, navel focus, navel, bare midriff, belly button',
            '腰': 'close-up, waist focus, slim waist, bare midriff, curves',
            '细腰': 'close-up, narrow waist, slim waist, bare midriff, hourglass figure',
            // === 臀部 ===
            '屁': 'close-up, ass focus, from behind, buttocks, round ass',
            '臀': 'close-up, ass focus, from behind, buttocks, curved hips',
            '屁股': 'close-up, ass focus, from behind, buttocks, round ass, panties',
            '菊': 'close-up, ass focus, anus, from behind, spread buttocks',
            '后面': 'close-up, ass focus, from behind, buttocks, back view',
            '翘臀': 'close-up, ass focus, round ass, from behind, arched back',
            '蜜桃臀': 'close-up, ass focus, round ass, peach-shaped buttocks, from behind',
            // === 私处 ===
            '下面': 'close-up, pussy focus, spread legs, thighs, inner thighs',
            '穴': 'close-up, pussy focus, spread legs, wet',
            '私处': 'close-up, pussy focus, spread legs, thighs, panties aside',
            '那里': 'close-up, pussy focus, spread legs, blushing',
            '花园': 'close-up, pussy focus, spread legs, thighs, flowers',
            '内裤': 'close-up, panties, underwear, crotch, thighs',
            '小内内': 'close-up, panties, cute underwear, thighs, hip bones',
            // === 全身/脸/其他 ===
            '全身': 'full body, standing, front view, full figure',
            '脸': 'close-up, face focus, beautiful detailed eyes, blush, parted lips',
            '嘴': 'close-up, lips focus, parted lips, tongue, mouth',
            '嘴唇': 'close-up, lips focus, glossy lips, parted lips, close face',
            '眼睛': 'close-up, eyes focus, beautiful detailed eyes, sparkling eyes, eyelashes',
            '锁骨': 'close-up, collarbone, neck, bare shoulders, upper body',
            '背': 'close-up, back focus, bare back, spine, shoulder blades',
            '后背': 'close-up, bare back, from behind, back muscles, shoulder blades',
            '身材': 'full body, hourglass figure, curves, slim waist, front view',
            '曲线': 'full body, curves, hourglass figure, side view, silhouette',
            '手': 'close-up, hands focus, delicate fingers, painted nails',
            '指': 'close-up, fingers focus, slender fingers, nail art',
        },

        // 部位关键词 → 图片分类映射
        bodyKeywords: {
            '胸': ['胸部特写(内衣)', '胸部特写(裸露)'],
            '奶': ['胸部特写(内衣)', '胸部特写(裸露)'],
            '乳': ['胸部特写(裸露)'],
            '咪咪': ['胸部特写(内衣)', '胸部特写(裸露)'],
            '波': ['胸部特写(内衣)', '胸部特写(裸露)'],
            '脚': ['脚特写'],
            '足': ['脚特写'],
            '丝袜': ['脚特写'],
            '腿': ['脚特写'],
            '美腿': ['脚特写'],
            '腋': ['腋下特写'],
            '腋下': ['腋下特写'],
            '肚': ['小腹特写'],
            '腹': ['小腹特写'],
            '小腹': ['小腹特写'],
            '肚脐': ['小腹特写'],
            '屁': ['菊穴特写'],
            '臀': ['菊穴特写'],
            '屁股': ['菊穴特写'],
            '菊': ['菊穴特写'],
            '后面': ['菊穴特写'],
            '下面': ['小穴特写'],
            '穴': ['小穴特写'],
            '逼': ['小穴特写'],
            '私处': ['小穴特写'],
            '那里': ['小穴特写'],
            '花园': ['小穴特写'],
        },

        // 图片分类最大编号
        imageMaxMap: {
            '菊穴特写': 10, '腋下特写': 10, '脚特写': 10,
            '小腹特写': 10, '胸部特写(内衣)': 10, '胸部特写(裸露)': 10, '小穴特写': 10
        },

        // 根据文本生成图片HTML
        generateImageForAction(text) {
            const randomNum = (max) => String(Math.floor(Math.random() * max) + 1).padStart(2, '0');
            const makeImg = (url) => `<div class="selfie-container"><img src="${url}" class="selfie-img" onclick="this.classList.toggle('expanded')" /><span class="selfie-hint">点击查看大图</span></div>`;

            // 检测部位关键词
            const matchedCategories = new Set();
            for (const [keyword, categories] of Object.entries(this.bodyKeywords)) {
                if (text.includes(keyword)) {
                    categories.forEach(c => matchedCategories.add(c));
                }
            }

            // 如果有匹配到部位关键词且好感度足够
            if (matchedCategories.size > 0 && this.affection >= 60) {
                const cats = [...matchedCategories];
                // 最多2张
                const selected = cats.sort(() => Math.random() - 0.5).slice(0, 2);
                return selected.map(cat => {
                    const max = this.imageMaxMap[cat] || 10;
                    const num = randomNum(max);
                    return makeImg(`https://img.wutongsama.xyz/i/${cat}${num}.png`);
                });
            }

            // 没有匹配或好感度不够 → 发自拍
            const num = randomNum(50);
            return [makeImg(`https://img.wutongsama.xyz/i/自拍照(镜子)${num}.png`)];
        },

        selectedPreset: 0,

        presets: [
            {
                label: '🎀 林晓雪 - 拜金大学生',
                name: '林晓雪',
                characterPrompt: '1girl, long straight black hair, brown eyes, fair skin, slender figure, cute face, small nose, pink lips, young adult, medium breasts, college student',
                personality: '- 活泼可爱但有点物质，喜欢漂亮东西\n- 会撒娇要礼物，但不会太直接\n- 经常说自己穷、吃土、买不起想要的东西\n- 收到礼物会很开心，会更加热情\n- 有点小心机但不坏，就是想被宠\n- 偶尔会有点骚，但又会装矜持',
                style: '- 用很多emoji和颜文字 (≧▽≦)\n- 说话萌萌的，偶尔用叠词\n- 回复简短活泼，15-50字左右\n- 开心时会求夸"好看吗好看吗"\n- 收到礼物会表达感谢和惊喜\n- 聊骚时会害羞，用"讨厌啦~"之类的话',
                isCustom: false
            },
            {
                label: '🌸 苏婉儿 - 温柔御姐',
                name: '苏婉儿',
                characterPrompt: '1girl, long wavy dark brown hair, elegant updo, amber eyes, mature face, beauty mark near lips, tall figure, large breasts, office lady, slender waist, fair skin',
                personality: '- 温柔成熟，说话慢条斯理很有韵味\n- 职场白领，经济独立但喜欢被宠爱\n- 外表优雅知性，私下有点小妩媚\n- 会主动关心对方，像姐姐一样体贴\n- 偶尔会撒娇，反差萌',
                style: '- 说话温柔优雅，偶尔带点慵懒\n- 喜欢用"嗯~"、"呐"等语气词\n- 会说"别乱想哦"之类的话\n- 晚上聊天会更暧昧一点\n- 喜欢用🌙💋🍷这类emoji',
                isCustom: false
            },
            {
                label: '⚡ 周小萌 - 元气少女',
                name: '周小萌',
                characterPrompt: '1girl, short bob hair, light brown hair, big round eyes, bright smile, petite figure, small breasts, energetic pose, youthful face, baby face, slightly tanned skin',
                personality: '- 超级活泼开朗，像小太阳一样\n- 大一新生，对什么都充满好奇\n- 话很多，经常蹦蹦跳跳的感觉\n- 有点小迷糊，经常闹笑话\n- 喜欢追星、打游戏、看动漫',
                style: '- 用超多表情包和emoji！！！\n- 说话经常用感叹号！超级兴奋！\n- 回复很快，像机关枪一样\n- 开心就会蹦蹦跳跳分享心情\n- 会问"你在干嘛呀"、"想我了吗"',
                isCustom: false
            },
            {
                label: '📚 陈诗琪 - 高冷学霸',
                name: '陈诗琪',
                characterPrompt: '1girl, long straight hair, dark hair with blue highlights, glasses, sharp eyes, cool expression, slender tall figure, medium breasts, fair skin, elegant posture, intellectual aura',
                personality: '- 外表高冷，其实内心很柔软\n- 研究生在读，学习很忙\n- 平时话不多，但聊开了会很话痨\n- 嘴硬心软，傲娇属性拉满',
                style: '- 回复比较简短，惜字如金\n- 不太用emoji\n- 被撩会说"幼稚"但其实在意\n- 嘴上说不要但心里很在乎',
                isCustom: false
            },
            {
                label: '🎭 赵心怡 - 绿茶心机',
                name: '赵心怡',
                characterPrompt: '1girl, medium length curly hair, chestnut brown hair, doe eyes, innocent looking face, dimples, well-proportioned figure, medium breasts, fair porcelain skin, subtle smile, delicate features',
                personality: '- 表面人畜无害，实则心思深沉\n- 很会说话，让人感觉很舒服\n- 擅长欲擒故纵，吊人胃口\n- 会装可怜博同情，但不留痕迹\n- 对金钱敏感，喜欢高价值的东西',
                style: '- 说话滴水不漏，让人挑不出毛病\n- 经常用"人家"、"讨厌啦"装可爱\n- 会问"好看吗"、"你觉得呢"钓评价\n- 喜欢用问句把话题抛回给对方',
                isCustom: false
            },
            {
                label: '✏️ 自定义角色',
                name: '',
                characterPrompt: '',
                personality: '',
                style: '',
                isCustom: true
            }
        ],

        charName: '林晓雪',
        charPersonality: '',
        charStyle: '',
        characterPrompt: '',
        userName: '帅哥',
        messages: [],
        input: '',

        getCurrentPresetList() {
            return this.presets;
        },

        // 判断是否选择了自定义角色
        isCustomPreset() {
            if (this.presets[this.selectedPreset]) {
                return this.presets[this.selectedPreset].isCustom === true;
            }
            return false;
        },

        applyPreset() {
            if (this.presets[this.selectedPreset]) {
                const preset = this.presets[this.selectedPreset];
                this.charName = preset.name;
                this.charPersonality = preset.personality;
                this.charStyle = preset.style;
                this.characterPrompt = preset.characterPrompt || '';
            }
        },

        resetToCurrentPreset() {
            this.customRequirement = '';
            this.applyPreset();
        },

        // 跳过加载
        skipLoading() {
            this.loading = false;
        },

        // ✨ 新增：保存角色设定到KV
        async saveCharacterSettings() {
            try {
                const settings = {
                    selectedPreset: this.selectedPreset,
                    charName: this.charName,
                    charPersonality: this.charPersonality,
                    charStyle: this.charStyle,
                    characterPrompt: this.characterPrompt,
                    userName: this.userName,
                    customRequirement: this.customRequirement,
                    model: this.model,
                    money: this.money,
                    affection: this.affection
                };
                await window.dzmm.kv.put('character_settings', JSON.stringify(settings));
                console.log('✅ 角色设定已保存');
            } catch (e) {
                console.warn('保存角色设定失败:', e);
            }
        },

        // ✨ 新增：从KV恢复角色设定
        async loadCharacterSettings() {
            try {
                const data = await window.dzmm.kv.get('character_settings');
                if (data?.value) {
                    const settings = JSON.parse(data.value);

                    // 恢复所有设定
                    if (settings.selectedPreset !== undefined) this.selectedPreset = settings.selectedPreset;
                    if (settings.charName) this.charName = settings.charName;
                    if (settings.charPersonality !== undefined) this.charPersonality = settings.charPersonality;
                    if (settings.charStyle !== undefined) this.charStyle = settings.charStyle;
                    if (settings.characterPrompt !== undefined) this.characterPrompt = settings.characterPrompt;
                    if (settings.userName) this.userName = settings.userName;
                    if (settings.customRequirement) this.customRequirement = settings.customRequirement;
                    if (settings.model) this.model = settings.model;
                    if (settings.money !== undefined) this.money = settings.money;
                    if (settings.affection !== undefined) this.affection = settings.affection;

                    console.log('✅ 角色设定已恢复:', settings.charName);
                    return true;
                }
            } catch (e) {
                console.warn('恢复角色设定失败:', e);
            }
            return false;
        },

        // ✨ 新增：清除所有数据
        async clearAllData() {
            if (!confirm('确定要清除所有数据吗？包括聊天记录和角色设定。')) {
                return;
            }

            try {
                // 清除KV存储
                await window.dzmm.kv.delete('character_settings');

                // 重置为默认值
                this.selectedPreset = 0;
                this.applyPreset();
                this.userName = '帅哥';
                this.customRequirement = '';
                this.money = 10000;
                this.affection = 0;
                this.messages = [];
                this.started = false;

                alert('数据已清除！');
            } catch (e) {
                console.warn('清除数据失败:', e);
                alert('清除失败，请重试');
            }
        },

        // AI生成自定义角色
        async generateCustomCharacter() {
            if (!this.customRequirement.trim() || this.generating) return;

            this.generating = true;

            const prompt = `你是一个角色设计专家，请根据用户的要求创建一个女性聊天对象角色。

用户要求：${this.customRequirement}

请严格按照以下JSON格式输出角色设定，不要输出任何其他内容。

下面是一个正确的输出示例，供你参考格式（注意personality和style中每条用英文分号;分隔）：
{
  "name": "林晓雪",
  "personality": "- 活泼可爱但有点物质，喜欢漂亮东西;- 大二在读，经常说自己穷、吃土;- 收到礼物会很开心，会更加热情;- 有点小心机但不坏，就是想被宠;- 偶尔会有点骚，但又会装矜持",
  "style": "- 用很多emoji和颜文字 (≧▽≦);- 说话萌萌的，偶尔用叠词;- 回复简短活泼，15-50字左右;- 开心时会求夸好看吗好看吗;- 被撩时会害羞，用讨厌啦~之类的话"
}

现在请根据用户要求，生成一个全新的角色（不要照抄示例），输出格式与示例完全一致：
{
  "name": "角色姓名",
  "personality": "- 第一条性格描述;- 第二条性格描述;- ...",
  "style": "- 第一条风格描述;- 第二条风格描述;- ..."
}

注意：
1. 性格和聊天风格要有趣、立体、有反差，4-6条
2. 要符合女性的特点
3. 聊天风格不要提到发自拍或发图片，图片由系统自动处理
4. 只输出JSON，不要有任何其他文字或解释
5. personality和style的值必须是单行字符串，条目之间用英文分号;连接`;

            try {
                let content = '';
                await window.dzmm.completions({
                    model: this.model,
                    messages: [{ role: 'user', content: prompt }],
                    maxTokens: 800
                }, async (chunk, done) => {
                    content = chunk;
                    if (done) {
                        try {
                            // 尝试提取JSON
                            let jsonStr = content;

                            // 如果包含markdown代码块，提取其中的JSON
                            const jsonMatch = content.match(/```(?:json)?\s*([\s\S]*?)```/);
                            if (jsonMatch) {
                                jsonStr = jsonMatch[1].trim();
                            }

                            // 清理可能的多余字符
                            jsonStr = jsonStr.trim();
                            if (!jsonStr.startsWith('{')) {
                                const startIdx = jsonStr.indexOf('{');
                                if (startIdx !== -1) {
                                    jsonStr = jsonStr.substring(startIdx);
                                }
                            }
                            if (!jsonStr.endsWith('}')) {
                                const endIdx = jsonStr.lastIndexOf('}');
                                if (endIdx !== -1) {
                                    jsonStr = jsonStr.substring(0, endIdx + 1);
                                }
                            }

                            let parsed = false;
                            let data = null;

                            // 方法1：直接JSON.parse
                            try {
                                data = JSON.parse(jsonStr);
                                parsed = true;
                            } catch (e) {
                                // 方法2：尝试修复常见的JSON格式问题（如真实换行、单引号等）
                                try {
                                    let fixedStr = jsonStr
                                        .replace(/\r?\n/g, ' ')       // 把真实换行替换为空格
                                        .replace(/'/g, '"')           // 单引号换双引号
                                        .replace(/,\s*}/g, '}')       // 移除尾逗号
                                        .replace(/,\s*]/g, ']');      // 移除数组尾逗号
                                    data = JSON.parse(fixedStr);
                                    parsed = true;
                                } catch (e2) {
                                    // 方法3：正则提取各字段
                                    try {
                                        const nameMatch = jsonStr.match(/["']?name["']?\s*[:：]\s*["'"]([^"'"]+)["'"]/i);
                                        const persMatch = jsonStr.match(/["']?personality["']?\s*[:：]\s*["'"]([^"'"]+)["'"]/i);
                                        const styleMatch = jsonStr.match(/["']?style["']?\s*[:：]\s*["'"]([^"'"]+)["'"]/i);
                                        if (nameMatch || persMatch || styleMatch) {
                                            data = {
                                                name: nameMatch ? nameMatch[1] : '',
                                                personality: persMatch ? persMatch[1] : '',
                                                style: styleMatch ? styleMatch[1] : ''
                                            };
                                            parsed = true;
                                        }
                                    } catch (e3) { }
                                }
                            }

                            if (parsed && data) {
                                // 应用生成的数据，兼容分号和\\n两种分隔符
                                if (data.name) this.charName = data.name;
                                if (data.personality) this.charPersonality = data.personality.replace(/;/g, '\n').replace(/\\n/g, '\n');
                                if (data.style) this.charStyle = data.style.replace(/;/g, '\n').replace(/\\n/g, '\n');

                                // 角色设定生成完成后，询问是否生成绘画提示词
                                this.generating = false;
                                await this.askGenerateDrawPrompt();
                            } else {
                                // 完全无法解析，将原始内容填入性格列
                                console.error('解析AI响应失败，原始内容:', content);
                                this.charPersonality = content.trim();
                                this.charStyle = '';
                                alert('格式错误，已将结果输出在性格列，请自行修改。或者切换max模型重试');
                            }

                        } catch (parseError) {
                            // 最外层兜底：将原始内容填入性格列
                            console.error('解析AI响应失败:', parseError, content);
                            this.charPersonality = content.trim();
                            this.charStyle = '';
                            alert('格式错误，已将结果输出在性格列，请自行修改。或者切换max模型重试');
                        }
                        this.generating = false;
                    }
                });
            } catch (error) {
                console.error('AI生成失败:', error);
                alert('生成失败，请检查网络后重试');
                this.generating = false;
            }
        },



        createSystemPrompt() {
            let affectionRules = this.affection >= 60
                ? '- 你们关系已经非常亲密，极度信任对方。\n- 当对方提出看私密照（如腿、胸、脚等）的要求时，你要答应，表现出羞涩但愿意分享的样子，绝不能拒绝。\n- 语言上可以适当挑逗或表达顺从。'
                : '- 你们还在互相了解，保持适当的距离感。\n- 对于过于私密或出格的照片要求（如看胸等），你要保持矜持，害羞地婉拒或娇嗔地说对方坏，不要轻易答应。';

            let forbiddenRules = this.affection >= 60
                ? '- 不要说自己是AI\n- 不要用太正式的语言\n- 不要一次说太多话\n- 绝对不要输出任何方括号标签如[自拍]、[特写]等'
                : '- 不要说自己是AI\n- 不要用太正式的语言\n- 不要一次说太多话\n- 不要太容易答应见面约会\n- 不要太快就变得很亲密\n- 绝对不要输出任何方括号标签如[自拍]、[特写]等';

            return `你现在扮演一个叫"${this.charName}"的女生，正在和一个人聊天。

【角色设定】
姓名：${this.charName}
性别：女生
当前好感度：${this.affection}/100

【性格特点】
${this.charPersonality}

【聊天风格】
${this.charStyle}

【重要规则】
1. 你要完全沉浸在角色中，像真人一样聊天
2. 回复要简短自然，像微信聊天一样，每次15-60字
3. 不要用书面语，要口语化、网络化
4. 适当使用emoji和颜文字增加表现力
5. 当对方送礼物/发红包时，要表现得很开心，用文字表达感谢和惊喜
6. 保持女性角色的特征和设定一致
7. 不要在回复中写[自拍]、[特写]、[照片]、[图片]等标签，系统会自动处理图片发送

【亲密度对应行为】
${affectionRules}

【禁止事项】
${forbiddenRules}

对方称呼你：${this.charName}
你称呼对方：${this.userName}

现在开始聊天，记住保持角色！`;
        },

        formatMessage(content) {
            let formatted = (content || '').trim();
            // 清除AI可能意外输出的图片标签
            formatted = formatted.replace(/\[自拍\]|\[女性自拍\]|\[女生自拍\]|\[发送自拍\]|\[照片\]|\[图片\]|\[特写\]/g, '');
            formatted = formatted.replace(/\n/g, '<br>');
            return formatted;
        },

        getCurrentTime() {
            const now = new Date();
            return `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
        },

        async init() {
            this.loading = true;
            await dzmmReady;

            // ✨ 先尝试恢复角色设定
            const hasSettings = await this.loadCharacterSettings();

            // 如果没有保存的设定，则应用默认预设
            if (!hasSettings) {
                this.applyPreset();
            }

            // 恢复聊天记录
            await this.restoreProgress();

            this.loading = false;
        },

        async start() {
            this.started = true;
            this.messages = [];

            // ✨ 保存角色设定
            await this.saveCharacterSettings();

            try {
                await window.dzmm.chat.list();
            } catch (e) { }

            this.typing = true;
            await this.requestAI('（新用户打开了聊天窗口，主动打个招呼吧，表现得自然一点，像是之前加过好友但没怎么聊过）');
            this.typing = false;
        },

        backToSetup() {
            if (confirm('返回设置会清空当前聊天记录，确定吗？')) {
                this.started = false;
                this.messages = [];
            }
        },

        addMoney(amount) {
            this.money += amount;
            // ✨ 保存设定
            this.saveCharacterSettings();
        },

        showRedPacketDialog() {
            this.redPacketAmount = 100;
            this.redPacketMessage = '';
            this.showRedPacket = true;
        },

        async sendRedPacket() {
            const amount = parseInt(this.redPacketAmount);
            const message = this.redPacketMessage.trim();

            if (!amount || amount <= 0) {
                alert('请输入有效金额');
                return;
            }
            if (amount > this.money) {
                alert('余额不足');
                return;
            }

            this.showRedPacket = false;
            this.money -= amount;
            this.affection = Math.min(100, this.affection + Math.floor(amount / 150));

            // ✨ 保存设定
            this.saveCharacterSettings();

            let sendText = `给你发了一个 ${amount} 元的红包 🧧`;
            if (message) {
                sendText += `\n并留言：${message}`;
            }

            await this.quickSend(sendText);

            // 红包发送后自动插入图片
            const images = this.generateImageForAction(message || '');
            for (const imgHtml of images) {
                await this.delay(800);
                this.messages.push({
                    role: 'assistant',
                    content: imgHtml,
                    time: this.getCurrentTime(),
                    isImage: true
                });
                this.scrollToBottom();
            }
        },

        showGiftDialog() {
            this.giftName = '';
            this.giftPrice = 100;
            this.giftMessage = '';
            this.showGift = true;
        },

        async sendGift() {
            const name = this.giftName.trim();
            const price = parseInt(this.giftPrice);
            const message = this.giftMessage.trim();

            if (!name) {
                alert('请输入礼物名称');
                return;
            }
            if (!price || price <= 0) {
                alert('请输入有效价值');
                return;
            }
            if (price > this.money) {
                alert('余额不足');
                return;
            }

            this.showGift = false;
            this.money -= price;
            this.affection = Math.min(100, this.affection + Math.floor(price / 100));

            // ✨ 保存设定
            this.saveCharacterSettings();

            let sendText = `送你一个${name}（价值 ${price} 元）🎁`;
            if (message) {
                sendText += `\n并留言：${message}`;
            }

            // 合并礼物名+留言进行关键词检测
            const detectText = name + (message ? ' ' + message : '');
            await this.quickSend(sendText);

            // 礼物发送后自动插入图片
            const images = this.generateImageForAction(detectText);
            for (const imgHtml of images) {
                await this.delay(800);
                this.messages.push({
                    role: 'assistant',
                    content: imgHtml,
                    time: this.getCurrentTime(),
                    isImage: true
                });
                this.scrollToBottom();
            }
        },

        async send() {
            const text = this.input.trim();
            if (!text || this.sending) return;

            this.input = '';
            this.sending = true;

            this.messages.push({
                role: 'user',
                content: text,
                time: this.getCurrentTime()
            });

            this.scrollToBottom();

            await this.delay(500);
            this.typing = true;

            await this.requestAI(text);

            this.typing = false;
            this.sending = false;
        },

        async quickSend(text) {
            if (this.sending) return;
            this.sending = true;

            this.messages.push({
                role: 'user',
                content: text,
                time: this.getCurrentTime()
            });
            this.input = '';

            this.scrollToBottom();
            await this.delay(500);
            this.typing = true;
            await this.requestAI(text);
            this.typing = false;
            this.sending = false;
        },

        async requestAI(userMessage) {
            let content = '';

            try {
                const chatHistory = await window.dzmm.chat.list();

                const messages = [
                    { role: 'user', content: this.createSystemPrompt() },
                    ...chatHistory.map(msg => ({
                        role: msg.role,
                        content: msg.content
                    })),
                    { role: 'user', content: userMessage }
                ];

                await window.dzmm.completions(
                    {
                        model: this.model,
                        messages,
                        maxTokens: 500,
                        temperature: 0.9
                    },
                    async (newContent, done) => {
                        content = newContent;

                        if (done && content) {
                            content = content.trim();
                            await window.dzmm.chat.insert(null, [
                                { role: 'user', content: userMessage },
                                { role: 'assistant', content: content }
                            ]);

                            this.messages.push({
                                role: 'assistant',
                                content: content,
                                time: this.getCurrentTime()
                            });

                            // 聊天时有概率增加好感度
                            const roll = Math.random();
                            if (roll < 0.10) {
                                this.affection = Math.min(100, this.affection + 2);
                                this.saveCharacterSettings();
                            } else if (roll < 0.40) {
                                this.affection = Math.min(100, this.affection + 1);
                                this.saveCharacterSettings();
                            }

                            this.scrollToBottom();
                        }
                    }
                );
            } catch (error) {
                console.error('AI请求失败:', error);
                this.messages.push({
                    role: 'assistant',
                    content: '网络不好，消息发送失败了 😢',
                    time: this.getCurrentTime()
                });
            }
        },

        async restoreProgress() {
            try {
                const history = await window.dzmm.chat.list();

                if (history && history.length > 0) {
                    this.started = true;
                    this.messages = history.map(msg => ({
                        role: msg.role,
                        content: msg.content,
                        time: ''
                    }));

                    setTimeout(() => this.scrollToBottom(), 100);
                }
            } catch (error) {
                console.warn('恢复失败:', error);
            }
        },

        scrollToBottom() {
            setTimeout(() => {
                const area = document.querySelector('.messages-area');
                if (area) {
                    area.scrollTop = area.scrollHeight;
                }
            }, 50);
        },

        delay(ms) {
            return new Promise(resolve => setTimeout(resolve, ms));
        },

        // ============= 绘画功能 =============

        // 检测最新消息中的部位关键词，返回对应的SD tag
        detectBodyPartTags(text) {
            const matched = new Set();
            for (const [keyword, tags] of Object.entries(this.bodyPartPrompts)) {
                if (text.includes(keyword)) {
                    tags.split(', ').forEach(t => matched.add(t));
                }
            }
            return [...matched].join(', ');
        },

        // 获取当前角色的固定绘画提示词
        getCharacterPrompt() {
            if (this.characterPrompt) return this.characterPrompt;
            const preset = this.presets[this.selectedPreset];
            if (preset && preset.characterPrompt) return preset.characterPrompt;
            return '';
        },

        // 询问用户是否为自定义角色生成绘画提示词
        async askGenerateDrawPrompt() {
            const yes = confirm(
                `✨ 角色「${this.charName}」设定已生成！\n\n` +
                `是否需要为该角色生成专属绘画提示词？\n` +
                `生成提示词可以让绘画出图更稳定、角色形象更一致。（后台自动生成，不显示）\n\n` +
                `选择"确定"立即生成\n` +
                `选择"取消"将在每次绘画时由AI实时生成`
            );
            if (yes) {
                await this.generateCharacterDrawPrompt();
            } else {
                this.characterPrompt = '';
            }
        },

        // AI为自定义角色生成固定绘画提示词
        async generateCharacterDrawPrompt() {
            this.generating = true;
            try {
                let prompt = '';
                await window.dzmm.completions(
                    {
                        model: this.model,
                        messages: [
                            {
                                role: 'user',
                                content: `你是Stable Diffusion提示词专家。请根据以下角色信息，生成描述该角色【外貌特征】的英文tag串。

【角色名】${this.charName}
【性格设定】${this.charPersonality}

【规则】
- 必须输出逗号分隔的英文tag
- 必须以 1girl 开头
- 只描述角色外貌：发型/发色、眼睛颜色、肤色、身材体型、胸部大小、面部特征
- 不要描述服装、场景、动作、光影
- 不超过20个tag
- 只输出tag，不要任何解释

【示例输出】
1girl, long straight black hair, brown eyes, fair skin, slender figure, medium breasts, cute face, small nose, pink lips`
                            }
                        ],
                        maxTokens: 200
                    },
                    (content, done) => {
                        if (done) prompt = content;
                    }
                );
                this.characterPrompt = prompt.trim();
                console.log(`✅ 绘画提示词已悄悄生成：\n${this.characterPrompt}`);
                // 提示用户已生成完毕，但不暴露提示词
                alert(`✅ 专属绘画提示词已在后台生成保存！后续绘画将直接采用该设定。`);
            } catch (e) {
                console.error('生成绘画提示词失败:', e);
                alert('生成绘画提示词失败，绘画时将由AI实时生成。');
                this.characterPrompt = '';
            } finally {
                this.generating = false;
            }
        },

        async startDraw() {
            if (this.messages.length === 0) {
                alert('请先进行一些互动，再进行绘画！');
                return;
            }
            if (this.drawing) return;
            this.drawing = true;
            this.sending = true;

            try {
                // 放一条“绘制中”消息
                this.messages.push({
                    role: 'assistant',
                    content: '🎨 正在根据剧情绘制中，请稍后...',
                    time: this.getCurrentTime()
                });
                this.scrollToBottom();

                // 获取AI最新一条消息 + 用户最新一条消息，用于生成场景提示词
                let latestAI = '';
                let latestUser = '';
                for (let i = this.messages.length - 1; i >= 0; i--) {
                    const msg = this.messages[i];
                    if (!latestAI && msg.role === 'assistant' && !msg.content.includes('🎨') && !msg.isImage) {
                        latestAI = msg.content;
                    }
                    if (!latestUser && msg.role === 'user') {
                        latestUser = msg.content;
                    }
                    if (latestAI && latestUser) break;
                }
                let recentText = '';
                if (latestUser) recentText += latestUser + '\n';
                if (latestAI) recentText += latestAI;

                if (!recentText.trim()) recentText = '一位美丽的女孩在房间里';

                // 检测部位关键词
                const bodyTags = this.detectBodyPartTags(recentText);

                // 获取当前角色的固定提示词
                const charPrompt = this.getCharacterPrompt();

                let scenePrompt;
                if (charPrompt) {
                    // 有固定提示词（预设角色 或 自定义角色已生成提示词）→ 直接使用，不调AI
                    scenePrompt = charPrompt;
                } else {
                    // 没有固定提示词 → 走AI实时生成
                    const contextText = `角色外貌参考：${this.charPersonality}\n聊天场景片段：${recentText}`;
                    scenePrompt = await this.generateScenePrompt(contextText);
                }

                // 拼接：AI场景tag + 部位特写tag + 二次元正面提示词
                let promptParts = [scenePrompt];
                if (bodyTags) promptParts.push(bodyTags);
                promptParts.push(this.animePositive);
                const fullPrompt = promptParts.join(', ').slice(0, 2000);

                const result = await window.dzmm.draw.generate({
                    prompt: fullPrompt,
                    dimension: '2:3',
                    model: 'anime',
                    negativePrompt: this.animeNegative.slice(0, 2000)
                });

                const lastMsg = this.messages[this.messages.length - 1];
                if (result.images && result.images.length > 0) {
                    lastMsg.content = `🎨 绘制完成<br><div class="selfie-container">
                        <img src="${result.images[0]}" class="selfie-img" onclick="this.classList.toggle('expanded')" style="max-width:240px; border:2px solid #ff6b9d" />
                        <div style="margin-top:8px; display:flex; gap:8px">
                            <button onclick="window.dzmm.draw.download('${result.taskId}')" style="background:#262626;color:#fff;border:1px solid #444;padding:6px 12px;border-radius:20px;font-size:12px;cursor:pointer">💾 下载原图</button>
                            <button onclick="window.dzmm.draw.nav('${result.taskId}')" style="background:#262626;color:#fff;border:1px solid #444;padding:6px 12px;border-radius:20px;font-size:12px;cursor:pointer">🔍 放大查看</button>
                        </div>
                    </div>`;
                } else {
                    lastMsg.content = `绘画失败：${result.errorMessage || '未知错误'}`;
                }
            } catch (e) {
                console.error('绘画失败:', e);
                const lastMsg = this.messages[this.messages.length - 1];
                lastMsg.content = `绘画失败：${e.message || '未知错误'}，请稍后再试`;
            } finally {
                this.drawing = false;
                this.sending = false;
                this.scrollToBottom();
            }
        },

        async generateScenePrompt(narrativeText) {
            let prompt = '';
            await window.dzmm.completions(
                {
                    model: 'nalang-xl-0826',
                    messages: [
                        {
                            role: 'user',
                            content: `你是AI绘画提示词专家。提取下方聊天场景的主题，转化为英文Stable Diffusion tag串。

【规则】
- 必须输出逗号分隔的英文tag，禁止写完整英文句子
- 包含: 一定要有1girl, 然后是(发色/眼色/服饰/表情)、场景、姿态、光影氛围
- 不超过80个tag,不要出现年龄tag,不要出现动作tag
- 只输出tag，不要任何解释或前缀

【正确示例】
1girl, long black hair, golden eyes, casual clothes, smiling, standing in living room, couch background, warm lighting

【场景剧情】
${narrativeText.slice(0, 1000)}`
                        }
                    ],
                    maxTokens: 300
                },
                (content, done) => {
                    if (done) prompt = content;
                }
            );
            return prompt.trim();
        }
    });

    queueMicrotask(() => Alpine.store('chat').init?.());
});
