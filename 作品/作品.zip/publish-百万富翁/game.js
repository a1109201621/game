/**
 * 百万富翁 – 爽文互动游戏
 *
 * 功能：
 * 1. 存档系统（dzmm.kv）  3个存档位
 * 2. 消息管理（编辑 / 重新生成 / 删除）
 * 3. AI 驱动的爽文剧情 + 数值追踪
 * 4. 跳过加载按钮
 */

// ---------- 通知父窗口 ----------
if (window.parent !== window) {
    window.parent.postMessage('iframe:content-ready', '*');
}

// ---------- SDK 就绪检测 ----------
function isDzmmInjected() {
    return !!(window.dzmm && window.dzmm.completions && window.dzmm.chat && window.dzmm.kv);
}

const dzmmReady = new Promise((resolve) => {
    if (isDzmmInjected()) return resolve('injected');

    const handler = (event) => {
        if (event.data?.type === 'dzmm:ready') {
            window.removeEventListener('message', handler);
            resolve('message');
        }
    };
    window.addEventListener('message', handler);

    const t0 = Date.now();
    const timer = setInterval(() => {
        if (isDzmmInjected()) {
            clearInterval(timer);
            window.removeEventListener('message', handler);
            resolve('poll');
            return;
        }
        if (Date.now() - t0 > 5000) {
            clearInterval(timer);
            window.removeEventListener('message', handler);
            resolve('timeout');
        }
    }, 100);
});

// ---------- Alpine Store ----------
document.addEventListener('alpine:init', () => {
    Alpine.store('game', {
        // ========== 基础状态 ==========
        started: false,
        disabled: false,
        loading: true,
        showSkipBtn: false,
        isGenerating: false,
        statsExpanded: true,

        // ========== 玩家配置 ==========
        playerName: '',
        model: 'nalang-xl-0826',
        origin: '',
        rulesExpanded: false,
        input: '',

        // ========== 游戏数值 ==========
        wealth: '0元',
        reputation: 10,
        charm: 10,
        empireLevel: 0,   // 0-4

        // ========== 消息与历史 ==========
        messages: [],   // [{id, role, content}]
        history: [],    // 用于AI上下文

        // ========== 弹窗状态 ==========
        saveManager: { open: false, fromSetup: false, summaries: {} },
        editModal: { open: false, index: -1, content: '' },
        deleteModal: { open: false, index: -1 },

        // ========== 帝国阶段 ==========
        empireNames: ['底层小人物', '初入富豪圈', '商界新贵', '商业巨头', '隐世财阀'],

        empireName() {
            return this.empireNames[Math.min(this.empireLevel, this.empireNames.length - 1)];
        },

        // ========== 起源描述 ==========
        originBackground() {
            const map = {
                blackcard: '你是一个负债累累的底层打工仔，网贷催收电话响个不停，老板当着同事的面骂你是废物，谈了三年的女友嫌你穷跟了开宝马的同事，你什么都没有',
                inherit: '你是一个从小被亲戚踢来踢去的孤儿，在亲戚家吃剩饭、穿旧衣、被表哥打骂，读完大学租了个地下室，连房租都快交不起了',
                system: '你是大学里最不起眉的人，成绩垫底、穿着土气、没钱没背景，室友当着女生的面嘲笑你“这辈子就这样了”，校花经过都不看你一眼',
                reborn: '前世的你是一个小老板，被最好的兄弟和自己的老婆联手背叛，公司被转走、老婆携款私奔，你身无分文被逼至天台，绝望中跳下去后重生到了十年前'
            };
            return map[this.origin] || '';
        },

        originTurningPoint() {
            const map = {
                blackcard: '就在你走投无路、坐在街边的时候，一辆劳斯莱斯停在你面前，一个穿着西装的人递给你一张全黑的卡片——一张无限额度的黑卡',
                inherit: '就在房东来赶你走的那天，一支由十几辆豪车组成的车队停在楼下，一群律师恍处找到你，告诉你：“您继承了三千亿遗产”',
                system: '一觉醒来，你脑海中多了个声音：“叮！【终极富翁系统】已绑定！首充奖励：10亿现金已到账！”你看了看手机银行余额，眆了',
                reborn: '你竟然重生了！回到了十年前，那时候你的公司刚刚起步，一切还来得及。你清楚未来十年每一支股票、每一个风口、每一个变数'
            };
            return map[this.origin] || '';
        },

        // ========== 初始化 ==========
        async init() {
            this.loading = true;

            setTimeout(() => {
                this.showSkipBtn = true;
            }, 3000);

            try {
                const result = await dzmmReady;
                if (result === 'timeout') {
                    console.warn('SDK超时');
                }
                await this.refreshSaveSummaries();
                this.loading = false;
            } catch (e) {
                console.error('初始化失败:', e);
                this.loading = false;
            }
        },

        skipLoading() {
            this.loading = false;
        },

        // ========== 存档系统（dzmm.kv） ==========
        slotKey(slot) {
            return `millionaire_save_${slot}`;
        },

        async kvPut(key, value) {
            try {
                await window.dzmm.kv.put(key, value);
            } catch (e) {
                console.warn('KV写入失败，使用localStorage:', e);
                localStorage.setItem(key, JSON.stringify(value));
            }
        },

        async kvGet(key) {
            try {
                const data = await window.dzmm.kv.get(key);
                return data?.value ?? null;
            } catch (e) {
                console.warn('KV读取失败，使用localStorage:', e);
                const raw = localStorage.getItem(key);
                if (!raw) return null;
                try { return JSON.parse(raw); } catch { return raw; }
            }
        },

        async refreshSaveSummaries() {
            for (let slot = 1; slot <= 3; slot++) {
                const data = await this.kvGet(this.slotKey(slot));
                if (data && data.savedAt) {
                    this.saveManager.summaries[slot] = {
                        savedAt: data.savedAt,
                        messageCount: data.messages?.length || 0
                    };
                } else {
                    this.saveManager.summaries[slot] = null;
                }
            }
        },

        getSaveInfo(slot) {
            const info = this.saveManager.summaries[slot];
            if (!info) return '（空）';
            return `${info.savedAt} | ${info.messageCount}条消息`;
        },

        openSaveManager(fromSetup) {
            this.saveManager.open = true;
            this.saveManager.fromSetup = !!fromSetup;
            this.refreshSaveSummaries();
        },

        async manualSave(slot) {
            if (!this.started) return;

            const saveData = {
                savedAt: new Date().toLocaleString('zh-CN'),
                playerName: this.playerName,
                model: this.model,
                origin: this.origin,
                wealth: this.wealth,
                reputation: this.reputation,
                charm: this.charm,
                empireLevel: this.empireLevel,
                messages: this.messages,
                history: this.history
            };

            await this.kvPut(this.slotKey(slot), saveData);
            await this.refreshSaveSummaries();
            alert(`已保存到存档位 ${slot}`);
        },

        async manualLoad(slot) {
            const data = await this.kvGet(this.slotKey(slot));
            if (!data) {
                alert('该存档位为空');
                return;
            }

            this.playerName = data.playerName || '玩家';
            this.model = data.model || 'nalang-xl-0826';
            this.origin = data.origin || 'blackcard';
            this.wealth = data.wealth || '0元';
            this.reputation = data.reputation ?? 10;
            this.charm = data.charm ?? 10;
            this.empireLevel = data.empireLevel ?? 0;
            this.messages = data.messages || [];
            this.history = data.history || [];

            this.started = true;
            this.saveManager.open = false;

            Alpine.nextTick(() => { this.scrollToBottom(); });
        },

        // ========== 游戏流程 ==========
        async start() {
            if (!this.playerName.trim() || !this.origin) return;

            this.started = true;
            this.disabled = true;
            this.isGenerating = true;

            try {
                const opening = await this.requestAIResponse('', true);
                this.addMessage('assistant', opening);
            } catch (e) {
                console.error('开场失败:', e);
                this.addMessage('assistant', '（加载失败，请刷新重试）');
            } finally {
                this.disabled = false;
                this.isGenerating = false;
            }
        },

        async sendMessage() {
            const text = this.input.trim();
            if (!text || this.disabled) return;

            this.input = '';
            this.disabled = true;
            this.isGenerating = true;

            this.addMessage('user', text);

            try {
                const response = await this.requestAIResponse(text, false);
                this.addMessage('assistant', response);
            } catch (e) {
                console.error('AI响应失败:', e);
                this.addMessage('assistant', '（剧情生成失败，请稍后再试）');
            } finally {
                this.disabled = false;
                this.isGenerating = false;
            }
        },

        addMessage(role, content) {
            const cleaned = this.cleanContent(content);

            this.messages.push({
                id: Date.now() + Math.random(),
                role,
                content: cleaned
            });

            this.history.push({ role, content: cleaned });
            this.trimHistory();

            Alpine.nextTick(() => { this.scrollToBottom(); });
        },

        scrollToBottom() {
            try {
                const panel = document.getElementById('chatPanel');
                if (panel) panel.scrollTop = panel.scrollHeight;
            } catch (e) { /* blob环境 */ }
        },

        trimHistory() {
            const MAX = 24;
            if (this.history.length > MAX) {
                this.history = this.history.slice(-MAX);
            }
        },

        // ========== AI 通信 ==========
        createSystemPrompt() {
            return `你是一个类似《百万富翁》原作小说风格的爽文叙事AI。

【重要设定】
主角名字：${this.playerName}
主角背景：${this.originBackground()}
转折点：${this.originTurningPoint()}
当前资产：${this.wealth}
社会声望：${this.reputation}/100
魅力值：${this.charm}/100
当前阶段：${this.empireName()}

【小说风格核心】
你写的是那种"从底层小人物一夜变大佬"的爽文小说，核心套路：

1、强烈反差：主角之前有多惨，现在就有多爽。每个场景都要先写别人如何看不起主角，然后主角轻描淡写地展现实力，最后所有人目瞪口呆、瞬间尼米。

2、打脸三要素：
   - 先被嘲笑/看不起/羞辱
   - 然后潮距回转（一个电话、一个动作、一句话）
   - 最后对方脸色剧变、大尼米、跪求原谅

3、经典打脸场景：
   - 前女友看到主角开豪车，后悔得哭
   - 以前的老板求主角投资
   - 商场店员看人下菜，主角简单地说"这层楼我买了"
   - 富二代耀武扬威，然后发现主角身份后蹩下
   - 绝色美女主动贴过来

4、美女描写：要详细写容貌、身材、穿着、表情。美女类型：冗艳美人秘书、娇嫉前女友、高冷女总裁、清纯校花、火辣女明星等。

5、对话风格：主角说话要淑淡装逼，不用太张扬，轻描淡写间展现实力。比如："这点小钱而已"、"这层楼我买了"、"你说的那个集团？是我的"

6、字数要求：每次回复400-800字，情节紧凑，每次必须有打脸场景或美女互动

【极其重要的输出格式】
你的每次回复必须严格按照以下模板：

###STATE
{"wealth":"资产描述","reputation":数字0到100,"charm":数字0到100,"empire":数字0到4,"summary":"一句话概括"}
###END
剧情正文

字段说明：
- wealth: 当前资产的文字描述，如"100万"、"10亿"、"万亿帝国"
- reputation: 社会声望0-100
- charm: 魅力值0-100  
- empire: 0=底层小人物, 1=初入富豪圈, 2=商界新贵, 3=商业巨头, 4=隐世财阀
- summary: 一句话概括

【正确示例】
###STATE
{"wealth":"10亿","reputation":35,"charm":42,"empire":1,"summary":"在商场被店员侮辱，一个电话买下整层楼"}
###END
"先生，这个包拿2万块，你确定要看吗？"店员粉头口文的脸上写满了不屑，眼神上下打量着${this.playerName}身上地摊货的T恤和起球的运动鞋......

【禁止事项】
❌ 不要把剧情写在STATE之前
❌ 不要省略STATE
❌ JSON必须在一行内完成`;
        },

        async requestAIResponse(userMessage, isOpening = false) {
            const messages = [
                { role: 'user', content: this.createSystemPrompt() }
            ];

            for (const msg of this.history) {
                messages.push({ role: msg.role, content: msg.content });
            }

            if (isOpening) {
                messages.push({
                    role: 'user',
                    content: `游戏开始！我是${this.playerName}。

我的悲惨背景：${this.originBackground()}

转折点：${this.originTurningPoint()}

请写一段精彩的开场：
1. 先用一小段描写我之前的悲惨处境（被人看不起、穷困潦倒）
2. 然后描写命运转折的重要时刻
3. 最后要让我立刻体验到第一次打脸的爽感！比如在曾经嘲笑我的人面前霍一下，或者让看不起我的人当场懵住。`
                });
            } else if (userMessage) {
                messages.push({ role: 'user', content: userMessage });
            }

            return new Promise((resolve, reject) => {
                let content = '';

                try {
                    window.dzmm.completions(
                        {
                            model: this.model,
                            messages,
                            maxTokens: 2000
                        },
                        (newContent, done) => {
                            content = newContent;

                            // 实时解析状态
                            const parsed = this.parseResponse(content);
                            if (parsed.ready) {
                                this.updateStats(parsed.state);
                            }

                            if (done) {
                                const final = this.parseResponse(content);
                                if (final.ready) {
                                    this.updateStats(final.state);
                                    resolve(final.dialogue);
                                } else {
                                    resolve(content.trim());
                                }
                            }
                        }
                    );
                } catch (e) {
                    reject(e);
                }
            });
        },

        parseResponse(content) {
            const stateMarker = '###STATE';
            const endMarker = '###END';
            const si = content.indexOf(stateMarker);
            const ei = content.indexOf(endMarker, si + stateMarker.length);

            if (si === -1 || ei === -1) return { ready: false };

            const jsonRaw = content.slice(si + stateMarker.length, ei).trim();
            try {
                const state = JSON.parse(jsonRaw);
                const dialogue = content.slice(ei + endMarker.length).trim();
                return { ready: true, state, dialogue };
            } catch {
                return { ready: false };
            }
        },

        updateStats(state) {
            if (state.wealth) this.wealth = state.wealth;
            if (typeof state.reputation === 'number') {
                this.reputation = Math.max(0, Math.min(100, state.reputation));
            }
            if (typeof state.charm === 'number') {
                this.charm = Math.max(0, Math.min(100, state.charm));
            }
            if (typeof state.empire === 'number') {
                this.empireLevel = Math.max(0, Math.min(4, state.empire));
            }
        },

        cleanContent(content) {
            return content
                .replace(/###STATE[\s\S]*?###END\s*/g, '')
                .trim();
        },

        // ========== 消息管理 ==========
        editMessage(index) {
            const msg = this.messages[index];
            if (!msg) return;

            this.editModal.index = index;
            this.editModal.content = msg.content.replace(/<[^>]*>/g, '');
            this.editModal.open = true;
        },

        confirmEdit() {
            const index = this.editModal.index;
            if (index < 0 || index >= this.messages.length) return;

            const newContent = this.editModal.content.trim();
            if (!newContent) return;

            this.messages[index].content = newContent;

            if (index < this.history.length) {
                this.history[index].content = newContent;
            }

            this.editModal.open = false;
        },

        deleteMessage(index) {
            this.deleteModal.index = index;
            this.deleteModal.open = true;
        },

        confirmDelete() {
            const index = this.deleteModal.index;
            if (index < 0 || index >= this.messages.length) return;

            this.messages.splice(index, 1);

            if (index < this.history.length) {
                this.history.splice(index, 1);
            }

            this.deleteModal.open = false;
        },

        async regenerateLastMessage() {
            if (this.messages.length === 0) return;

            const lastIndex = this.messages.length - 1;
            const lastMsg = this.messages[lastIndex];

            if (lastMsg.role !== 'assistant') return;

            this.disabled = true;
            this.isGenerating = true;

            // 移除最后一条 AI 回复
            this.messages.pop();
            this.history.pop();

            // 获取最后一条用户消息
            let lastUserMsg = '';
            for (let i = this.history.length - 1; i >= 0; i--) {
                if (this.history[i].role === 'user') {
                    lastUserMsg = this.history[i].content;
                    break;
                }
            }

            try {
                const response = await this.requestAIResponse(lastUserMsg, false);
                this.addMessage('assistant', response);
            } catch (e) {
                console.error('重新生成失败:', e);
                this.addMessage('assistant', '（重新生成失败，请稍后再试）');
            } finally {
                this.disabled = false;
                this.isGenerating = false;
            }
        }
    });

    // 启动初始化
    queueMicrotask(() => Alpine.store('game').init?.());
});
